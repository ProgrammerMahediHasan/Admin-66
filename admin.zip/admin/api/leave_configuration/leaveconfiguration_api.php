<?php
class LeaveConfigurationApi{
	public function __construct(){
	}
	function index(){
		echo json_encode(["leave_configuration"=>LeaveConfiguration::all()]);
	}
	function pagination($data){
		$page=$data["page"];
		$perpage=$data["perpage"];
		echo json_encode(["leave_configuration"=>LeaveConfiguration::pagination($page,$perpage),"total_records"=>LeaveConfiguration::count()]);
	}
	function find($data){
		echo json_encode(["leaveconfiguration"=>LeaveConfiguration::find($data["id"])]);
	}
	function delete($data){
		LeaveConfiguration::delete($data["id"]);
		echo json_encode(["success" => "yes"]);
	}


	function save($data,$file=[]){
		$leaveconfiguration=new LeaveConfiguration();
		$leaveconfiguration->leave_type=$data["leave_type"];
		$leaveconfiguration->total_days=$data["total_days"];
		$leaveconfiguration->carry_forward=$data["carry_forward"];
		$leaveconfiguration->description=$data["description"];
		$leaveconfiguration->status=$data["status"];

		$leaveconfiguration->save();
		echo json_encode(["success" => "yes"]);
	}


	function update($data,$file=[]){
		$leaveconfiguration=new LeaveConfiguration();
		$leaveconfiguration->id=$data["id"];
		$leaveconfiguration->leave_type=$data["leave_type"];
		$leaveconfiguration->total_days=$data["total_days"];
		$leaveconfiguration->carry_forward=$data["carry_forward"];
		$leaveconfiguration->description=$data["description"];
		$leaveconfiguration->status=$data["status"];

		$leaveconfiguration->update();
		echo json_encode(["success" => "yes"]);
	}
	
}
?>

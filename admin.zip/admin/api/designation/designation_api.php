<?php
class DesignationApi{
	public function __construct(){
	}
	function index(){
		echo json_encode(["designations"=>Designation::Getall()]);
	}
	function pagination($data){
		$page=$data["page"];
		$perpage=$data["perpage"];
		echo json_encode(["designations"=>Designation::pagination($page,$perpage),"total_records"=>Designation::count()]);
	}
	function find($data){
		echo json_encode(["designation"=>Designation::find($data["id"])]);
	}
	function delete($data){
		Designation::delete($data["id"]);
		echo json_encode(["success" => "yes"]);
	}
	function save($data,$file=[]){
		$designation=new Designation();
		$designation->dept_id=$data["dept_id"];
		$designation->name=$data["name"];
		$designation->description=$data["description"];

		$designation->save();
		echo json_encode(["success" => "yes"]);
	}
	function update($data,$file=[]){
		$designation=new Designation();
		$designation->id=$data["id"];
		$designation->dept_id=$data["dept_id"];
		$designation->name=$data["name"];
		$designation->description=$data["description"];

		$designation->update();
		echo json_encode(["success" => "yes"]);
	}
}
?>

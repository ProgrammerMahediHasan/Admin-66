<?php
class LeaveRequestApi{
	public function __construct(){
	}
	function index(){
		echo json_encode(["leave_request"=>LeaveRequest::all()]);
	}
	function pagination($data){
		$page=$data["page"];
		$perpage=$data["perpage"];
		echo json_encode(["leave_request"=>LeaveRequest::pagination($page,$perpage),"total_records"=>LeaveRequest::count()]);
	}
	function find($data){
		echo json_encode(["leaverequest"=>LeaveRequest::find($data["id"])]);
	}
	function delete($data){
		LeaveRequest::delete($data["id"]);
		echo json_encode(["success" => "yes"]);
	}
	function save($data,$file=[]){
		$leaverequest=new LeaveRequest();
		$leaverequest->emp_id=$data["emp_id"];
		$leaverequest->leave_type=$data["leave_type"];
		$leaverequest->from_date=$data["from_date"];
		$leaverequest->to_date=$data["to_date"];
		$leaverequest->total_days=$data["total_days"];
		$leaverequest->reason=$data["reason"];
		$leaverequest->attachment=$data["attachment"];
		$leaverequest->approved_by=$data["approved_by"];

		$leaverequest->save();
		echo json_encode(["success" => "yes"]);
	}
	function update($data,$file=[]){
		$leaverequest=new LeaveRequest();
		$leaverequest->id=$data["id"];
		$leaverequest->emp_id=$data["emp_id"];
		$leaverequest->leave_type=$data["leave_type"];
		$leaverequest->from_date=$data["from_date"];
		$leaverequest->to_date=$data["to_date"];
		$leaverequest->total_days=$data["total_days"];
		$leaverequest->reason=$data["reason"];
		$leaverequest->attachment=$data["attachment"];
		$leaverequest->approved_by=$data["approved_by"];

		$leaverequest->update();
		echo json_encode(["success" => "yes"]);
	}
}
?>

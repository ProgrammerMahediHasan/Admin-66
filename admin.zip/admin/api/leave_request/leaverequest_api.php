<?php
class LeaveRequestApi{
	public function __construct(){
	}
	function index(){
		echo json_encode(["leave_request"=>LeaveRequest::all()]);
	}
	function pagination($data){
		$page=$data["page"];
		$perpage=$data["perpage"];
		echo json_encode(["leave_request"=>LeaveRequest::pagination($page,$perpage),"total_records"=>LeaveRequest::count()]);
	}
	function find($data){
		echo json_encode(["leaverequest"=>LeaveRequest::find($data["id"])]);
	}
	function delete($data){
		LeaveRequest::delete($data["id"]);
		echo json_encode(["success" => "yes"]);
	}
	function save($data,$file=[]){
		$leaverequest=new LeaveRequest();
		$leaverequest->leave_id=$data["leave_id"];
		$leaverequest->emp_id=$data["emp_id"];
		$leaverequest->leave_type=$data["leave_type"];
		$leaverequest->start_date=$data["start_date"];
		$leaverequest->end_date=$data["end_date"];
		$leaverequest->reason=$data["reason"];
		$leaverequest->approver_id=$data["approver_id"];
		$leaverequest->applied_on=$data["applied_on"];

		$leaverequest->save();
		echo json_encode(["success" => "yes"]);
	}
	function update($data,$file=[]){
		$leaverequest=new LeaveRequest();
		$leaverequest->id=$data["id"];
		$leaverequest->leave_id=$data["leave_id"];
		$leaverequest->emp_id=$data["emp_id"];
		$leaverequest->leave_type=$data["leave_type"];
		$leaverequest->start_date=$data["start_date"];
		$leaverequest->end_date=$data["end_date"];
		$leaverequest->reason=$data["reason"];
		$leaverequest->approver_id=$data["approver_id"];
		$leaverequest->applied_on=$data["applied_on"];

		$leaverequest->update();
		echo json_encode(["success" => "yes"]);
	}
}
?>

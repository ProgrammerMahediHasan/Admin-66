<?php
class LeavePolicyController extends Controller{
	public function __construct(){
	}
	public function index(){
		view("leave_policy");
	}
	public function create(){
		view("leave_policy");
	}
public function save($data,$file){
	if(isset($data["create"])){
	$errors=[];
/*
	if(!preg_match("/^[\s\S]+$/",$_POST["txtLeaveType"])){
		$errors["leave_type"]="Invalid leave_type";
	}
	if(!preg_match("/^[\s\S]+$/",$data["days_allowed"])){
		$errors["days_allowed"]="Invalid days_allowed";
	}
	if(!preg_match("/^[\s\S]+$/",$data["approval_required"])){
		$errors["approval_required"]="Invalid approval_required";
	}
	if(!preg_match("/^[\s\S]+$/",$data["notes"])){
		$errors["notes"]="Invalid notes";
	}

*/
		if(count($errors)==0){
			$leavepolicy=new LeavePolicy();
		$leavepolicy->leave_type=$data["leave_type"];
		$leavepolicy->days_allowed=$data["days_allowed"];
		$leavepolicy->approval_required=$data["approval_required"];
		$leavepolicy->notes=$data["notes"];
		$leavepolicy->created_time=$now;

			$leavepolicy->save();
		redirect();
		}else{
			 print_r($errors);
		}
	}
}
public function edit($id){
		view("leave_policy",LeavePolicy::find($id));
}
public function update($data,$file){
	if(isset($data["update"])){
	$errors=[];
/*
	if(!preg_match("/^[\s\S]+$/",$_POST["txtLeaveType"])){
		$errors["leave_type"]="Invalid leave_type";
	}
	if(!preg_match("/^[\s\S]+$/",$data["days_allowed"])){
		$errors["days_allowed"]="Invalid days_allowed";
	}
	if(!preg_match("/^[\s\S]+$/",$data["approval_required"])){
		$errors["approval_required"]="Invalid approval_required";
	}
	if(!preg_match("/^[\s\S]+$/",$data["notes"])){
		$errors["notes"]="Invalid notes";
	}

*/
		if(count($errors)==0){
			$leavepolicy=new LeavePolicy();
			$leavepolicy->id=$data["id"];
		$leavepolicy->leave_type=$data["leave_type"];
		$leavepolicy->days_allowed=$data["days_allowed"];
		$leavepolicy->approval_required=$data["approval_required"];
		$leavepolicy->notes=$data["notes"];
		$leavepolicy->created_time=$now;

		$leavepolicy->update();
		redirect();
		}else{
			 print_r($errors);
		}
	}
}
	public function confirm($id){
		view("leave_policy");
	}
	public function delete($id){
		LeavePolicy::delete($id);
		redirect();
	}
	public function show($id){
		view("leave_policy",LeavePolicy::find($id));
	}
}
?>

<?php

class LeaveController {

    // Show all leave applications
    public function index() {
        $leaves = Leave::getAll();
        view("dashboard", $leaves);
    }

    // Show create leave form
    public function create() {
        view("dashboard");
    }

    // Save new leave application
    public function save() {
        if (isset($_POST['create'])) {
            $id        = $_POST['id'];
            $leave_type    = $_POST['leave_type'];
            $start_date    = $_POST['start_date'];
            $end_date      = $_POST['end_date'];
            $total_days    = $_POST['total_days'];
            $is_half_day   = isset($_POST['is_half_day']) ? 1 : 0;
            $reason        = $_POST['reason'];
            $attachment    = null;

            // Attachment upload (optional)
            if (isset($_FILES['attachment']) && $_FILES['attachment']['name'] != "") {
                $filename = time() . "_" . basename($_FILES['attachment']['name']);
                $target_dir = "uploads/leave/";
                if(!is_dir($target_dir)) mkdir($target_dir, 0777, true);
                $target = $target_dir . $filename;
                if(move_uploaded_file($_FILES['attachment']['tmp_name'], $target)){
                    $attachment = $filename;
                }
            }

            $status        = 'Pending';
            $applied_date  = date('Y-m-d H:i:s');
            $approved_by   = null;
            $approved_date = null;
            $remarks       = '';
            $leave_balance = $_POST['leave_balance'] ?? 0;

            $leave = new Leave(
                null,
                $id,
                $leave_type,
                $start_date,
                $end_date,
                $total_days,
                $is_half_day,
                $reason,
                $attachment,
                $status,
                $applied_date,
                $approved_by,
                $approved_date,
                $remarks,
                $leave_balance
            );

            $leave->save();
            redirect();
        }
    }

    // Show edit form
    public function edit($leave_id) {
        $leave = Leave::find($leave_id);
        view("dashboard", $leave);
    }

    // Update leave application
    public function update() {
        if (isset($_POST['update'])) {
            $leave_id      = $_POST['leave_id'];
            $id        = $_POST['id'];
            $leave_type    = $_POST['leave_type'];
            $start_date    = $_POST['start_date'];
            $end_date      = $_POST['end_date'];
            $total_days    = $_POST['total_days'];
            $is_half_day   = isset($_POST['is_half_day']) ? 1 : 0;
            $reason        = $_POST['reason'];
            $attachment    = $_POST['old_attachment'] ?? null;

            // Attachment upload (optional)
            if (isset($_FILES['attachment']) && $_FILES['attachment']['name'] != "") {
                $filename = time() . "_" . basename($_FILES['attachment']['name']);
                $target_dir = "uploads/leave/";
                if(!is_dir($target_dir)) mkdir($target_dir, 0777, true);
                $target = $target_dir . $filename;
                if(move_uploaded_file($_FILES['attachment']['tmp_name'], $target)){
                    $attachment = $filename;
                }
            }

            $status        = $_POST['status'] ?? 'Pending';
            $applied_date  = $_POST['applied_date'] ?? date('Y-m-d H:i:s');
            $approved_by   = $_POST['approved_by'] ?? null;
            $approved_date = $_POST['approved_date'] ?? null;
            $remarks       = $_POST['remarks'] ?? '';
            $leave_balance = $_POST['leave_balance'] ?? 0;

            $leave = new Leave(
                $leave_id,
                $id,
                $leave_type,
                $start_date,
                $end_date,
                $total_days,
                $is_half_day,
                $reason,
                $attachment,
                $status,
                $applied_date,
                $approved_by,
                $approved_date,
                $remarks,
                $leave_balance
            );

            $leave->update();
            redirect();
        }
    }

    // Delete leave application
    public function delete($leave_id) {
        Leave::delete($leave_id);
        redirect();
    }
}

?>

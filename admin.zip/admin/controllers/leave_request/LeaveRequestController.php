<?php
class LeaveRequestController extends Controller{
	public function __construct(){
	}
	public function index(){
		view("leave_request");
	}
	public function create(){
		view("leave_request");
	}
public function save($data,$file){
	if(isset($data["create"])){
	$errors=[];
/*
	if(!preg_match("/^[\s\S]+$/",$data["leave_id"])){
		$errors["leave_id"]="Invalid leave_id";
	}
	if(!preg_match("/^[\s\S]+$/",$data["emp_id"])){
		$errors["emp_id"]="Invalid emp_id";
	}
	if(!preg_match("/^[\s\S]+$/",$_POST["txtLeaveType"])){
		$errors["leave_type"]="Invalid leave_type";
	}
	if(!preg_match("/^[\s\S]+$/",$data["start_date"])){
		$errors["start_date"]="Invalid start_date";
	}
	if(!preg_match("/^[\s\S]+$/",$data["end_date"])){
		$errors["end_date"]="Invalid end_date";
	}
	if(!preg_match("/^[\s\S]+$/",$data["total_days"])){
		$errors["total_days"]="Invalid total_days";
	}
	if(!preg_match("/^[\s\S]+$/",$data["reason"])){
		$errors["reason"]="Invalid reason";
	}
	if(!preg_match("/^[\s\S]+$/",$data["status"])){
		$errors["status"]="Invalid status";
	}
	if(!preg_match("/^[\s\S]+$/",$data["approver_id"])){
		$errors["approver_id"]="Invalid approver_id";
	}

*/
		if(count($errors)==0){
			$leaverequest=new LeaveRequest();
		$leaverequest->leave_id=$data["leave_id"];
		$leaverequest->emp_id=$data["emp_id"];
		$leaverequest->leave_type=$data["leave_type"];
		$leaverequest->start_date=$data["start_date"];
		$leaverequest->end_date=$data["end_date"];
		$leaverequest->total_days=$data["total_days"];
		$leaverequest->reason=$data["reason"];
		$leaverequest->status=$data["status"];
		$leaverequest->approver_id=$data["approver_id"];
		$leaverequest->applied_on=date("Y-m-d",strtotime($data["applied_on"]));

			$leaverequest->save();
		redirect();
		}else{
			 print_r($errors);
		}
	}
}
public function edit($id){
		view("leave_request",LeaveRequest::find($id));
}
public function update($data,$file){
	if(isset($data["update"])){
	$errors=[];
/*
	if(!preg_match("/^[\s\S]+$/",$data["leave_id"])){
		$errors["leave_id"]="Invalid leave_id";
	}
	if(!preg_match("/^[\s\S]+$/",$data["emp_id"])){
		$errors["emp_id"]="Invalid emp_id";
	}
	if(!preg_match("/^[\s\S]+$/",$_POST["txtLeaveType"])){
		$errors["leave_type"]="Invalid leave_type";
	}
	if(!preg_match("/^[\s\S]+$/",$data["start_date"])){
		$errors["start_date"]="Invalid start_date";
	}
	if(!preg_match("/^[\s\S]+$/",$data["end_date"])){
		$errors["end_date"]="Invalid end_date";
	}
	if(!preg_match("/^[\s\S]+$/",$data["total_days"])){
		$errors["total_days"]="Invalid total_days";
	}
	if(!preg_match("/^[\s\S]+$/",$data["reason"])){
		$errors["reason"]="Invalid reason";
	}
	if(!preg_match("/^[\s\S]+$/",$data["status"])){
		$errors["status"]="Invalid status";
	}
	if(!preg_match("/^[\s\S]+$/",$data["approver_id"])){
		$errors["approver_id"]="Invalid approver_id";
	}

*/
		if(count($errors)==0){
			$leaverequest=new LeaveRequest();
			$leaverequest->id=$data["id"];
		$leaverequest->leave_id=$data["leave_id"];
		$leaverequest->emp_id=$data["emp_id"];
		$leaverequest->leave_type=$data["leave_type"];
		$leaverequest->start_date=$data["start_date"];
		$leaverequest->end_date=$data["end_date"];
		$leaverequest->total_days=$data["total_days"];
		$leaverequest->reason=$data["reason"];
		$leaverequest->status=$data["status"];
		$leaverequest->approver_id=$data["approver_id"];
		$leaverequest->applied_on=date("Y-m-d",strtotime($data["applied_on"]));

		$leaverequest->update();
		redirect();
		}else{
			 print_r($errors);
		}
	}
}
	public function confirm($id){
		view("leave_request");
	}
	public function delete($id){
		LeaveRequest::delete($id);
		redirect();
	}
	public function show($id){
		view("leave_request",LeaveRequest::find($id));
	}
}
?>

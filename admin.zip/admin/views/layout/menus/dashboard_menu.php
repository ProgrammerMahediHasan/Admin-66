<li class="nav-item">
            <a href="home" class="nav-link">
              <i class="nav-icon fa fa-th"></i>
              <p>
                Dashboard
              </p>
            </a>
</li>


<li class="nav-item">
    <a href="<?php echo $base_url?>/purchase" class="nav-link">
        <i class="nav-icon fa fa-th"></i>
        <p>
          Purchase
        </p>
    </a>
</li>
<li class="nav-item">
    <a href="<?php echo $base_url?>/logout.php" class="nav-link">
        <i class="nav-icon fa fa-th"></i>
        <p>
          Logout
        </p>
    </a>
</li>
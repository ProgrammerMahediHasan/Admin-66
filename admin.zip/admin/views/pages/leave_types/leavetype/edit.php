<?php
// echo Page::title(["title"=>"Edit LeaveType"]);
echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leavetype", "text"=>"Back Page"]);
echo Page::context_open();
echo Form::open(["route"=>"leavetype/update"]);
	echo Form::input(["label"=>"Id","type"=>"hidden","name"=>"id","value"=>"$leavetype->id"]);
	echo Form::input(["label"=>"Leave Name","type"=>"text","name"=>"name","value"=>"$leavetype->name"]);
	echo Form::input(["label"=>"Leave Code","type"=>"text","name"=>"leave_code","value"=>"$leavetype->leave_code"]);
	echo Form::input(["label"=>"Total Days","type"=>"text","name"=>"total_days","value"=>"$leavetype->total_days"]);
	echo Form::input(["label"=>"Description","type"=>"text","name"=>"description","value"=>"$leavetype->description"]);
	echo Form::input(["label"=>"Status","type"=>"text","name"=>"status","value"=>"$leavetype->status"]);

	echo '<p>&nbsp;</p>';
echo Form::input(["name"=>"update","class"=>"btn btn-success offset-2" , "value"=>"Update Chanage", "type"=>"submit"]);
echo Form::close();
echo Page::context_close();
echo Page::body_close();

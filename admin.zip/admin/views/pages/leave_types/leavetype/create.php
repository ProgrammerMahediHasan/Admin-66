<?php
// echo Page::title(["title"=>"Create LeaveType"]);

echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leavetype", "text"=>"Back Page"]);
echo Page::context_open();

echo Form::open(["route"=>"leavetype/save"]);
	echo Form::input(["label"=>"Leave Name","type"=>"text","name"=>"name"]);
	echo Form::input(["label"=>"Leave Code","type"=>"text","name"=>"leave_code" ]);
	echo Form::input(["label"=>"Total Days","type"=>"text","name"=>"total_days"]);
	echo Form::input(["label"=>"Description","type"=>"text","name"=>"description"]);
	echo Form::input(["label"=>"Status","type"=>"text","name"=>"status"]);

echo '<p>&nbsp;</p>'; 


echo Form::input(["name"=>"create","class"=>"btn btn-primary offset-2", "value"=>"Save", "type"=>"submit"]);
echo Form::close();
echo Page::context_close();
echo Page::body_close();

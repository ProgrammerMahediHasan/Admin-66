<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Employee Payslip | NEXTPRIME</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f6f9;
      padding: 20px;
      margin: 0;
    }

    #employeeSelection {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 90vh;
      text-align: center;
    }

    select {
      padding: 12px 16px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 6px;
      background-color: #fff;
      color: #333;
      min-width: 250px;
      appearance: none;
      background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D'16'%20height%3D'16'%20fill%3D'%23666'%20xmlns%3D'http%3A//www.w3.org/2000/svg'%3E%3Cpath%20d%3D'M4%206l4%204%204-4'%20/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 12px center;
      background-size: 12px;
      transition: border-color 0.3s ease;
      cursor: pointer;
    }

    select:focus {
      border-color: #0077ff;
      outline: none;
      box-shadow: 0 0 0 2px rgba(0,119,255,0.2);
    }

    button {
      padding: 12px 24px;
      font-size: 16px;
      background-color: #0077ff;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      margin-top: 15px;
      transition: background-color 0.3s ease;
      min-width: 150px;
    }

    button:hover {
      background-color: #005fcc;
    }

    .payslip-container {
      max-width: 900px;
      margin: 30px auto;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      overflow: hidden;
      display: none; /* hidden initially */
    }

    .payslip-header {
      background: linear-gradient(90deg, #304f74, #1f3a58);
      color: #fff;
      padding: 20px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .payslip-header h2 { font-size: 22px; font-weight: 600; margin: 0; }
    .payslip-header img { width: 70px; background: #fff; padding: 5px; border-radius: 10px; }

    .payslip-body { padding: 25px 30px; }

    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 20px;
    }

    .info-box {
      background: #f8fafc;
      border-radius: 8px;
      padding: 15px;
    }

    .info-box h4 {
      color: #244e81;
      font-size: 15px;
      margin-bottom: 8px;
      border-bottom: 1px solid #e3e3e3;
      padding-bottom: 5px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    th, td {
      padding: 10px 8px;
      border: 1px solid #ddd;
      font-size: 14px;
    }

    th { background: #304f744f; text-align: left; }
    td:last-child, th:last-child { text-align: right; }

    .totals {
      display: flex;
      justify-content: flex-end;
      margin-top: 20px;
    }

    .totals-box {
      background: #30496810;
      padding: 15px;
      border-radius: 8px;
      min-width: 300px;
    }

    .totals-box div {
      display: flex;
      justify-content: space-between;
      padding: 5px 0;
      font-size: 14px;
    }

    .net {
      font-weight: 700;
      color: #0077ff;
      font-size: 16px;
    }

    .print-btn {
      display: block;
      margin: 25px auto;
      background: #334a66dc;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 6px;
      font-size: 18px;
      cursor: pointer;
    }

    footer {
      margin-top: 40px;
      text-align: center;
      font-size: 12px;
      color: #777;
      border-top: 1px solid #eee;
      padding: 15px 0;
    }

    @media print {
      .print-btn, #employeeSelection { display: none !important; }
      body { background: #fff; padding: 0; }
      .payslip-container { box-shadow: none; border-radius: 0; }
    }
  </style>
</head>
<body>

  <!-- Employee Selector (Visible First) -->
  <div id="employeeSelection">
    <h2>Select Employee to View Payslip</h2>
    <select id="employeeSelect">
      <option value="">Choose Employee</option>
      <option value="1">Mahedi Hasan</option>
      <option value="2">Jannatul Ferdous</option>
      <option value="3">Hasan Mahmud</option>
    </select>
    <button onclick="showPayslip()">Show Payslip</button>
  </div>

  <!-- Payslip Report (Hidden Initially) -->
  <div class="payslip-container" id="payslipContainer">
    <div class="payslip-header">
      <div>
        <h2 id="companyName">NEXTPRIME LIMITED</h2>
        <small id="companyInfo">Dhanmondi, Dhaka | +880 1234 567890</small>
      </div>
      <img id="companyLogo" src="/PHP_Converted/admin/assets/images/HRMS_Icon.png" alt="Logo" />
    </div>

    <div class="payslip-body">
      <div class="info-grid">
        <div class="info-box">
          <h4>Employee Information</h4>
          <p>
            <strong>Name:</strong> <span id="empName"></span><br />
            <strong>Emp ID:</strong> <span id="empId"></span><br />
            <strong>Department:</strong> <span id="empDept"></span><br />
            <strong>Designation:</strong> <span id="empDesig"></span>
          </p>
        </div>
        <div class="info-box">
          <h4>Payment Information</h4>
          <p>
            <strong>Pay Date:</strong> <span id="payDate"></span><br />
            <strong>Bank:</strong> <span id="bankName"></span><br />
            <strong>Account:</strong> <span id="bankAcc"></span><br />
            <strong>Salary Month:</strong> <span id="salaryMonth"></span>
          </p>
        </div>
      </div>

      <h4>Earnings</h4>
      <table id="earningsTable">
        <thead>
          <tr><th>Description</th><th>Amount (৳)</th></tr>
        </thead>
        <tbody></tbody>
      </table>

      <h4 style="margin-top:20px;">Deductions</h4>
      <table id="deductionsTable">
        <thead>
          <tr><th>Description</th><th>Amount (৳)</th></tr>
        </thead>
        <tbody></tbody>
      </table>

      <div class="totals">
        <div class="totals-box">
          <div><span>Gross Salary:</span><span id="grossSalary">৳0.00</span></div>
          <div><span>Total Deductions:</span><span id="totalDeductions">৳0.00</span></div>
          <hr />
          <div class="net"><span>Net Pay:</span><span id="netPay">৳0.00</span></div>
        </div>
      </div>

      <button class="print-btn" onclick="window.print()">Print PDF</button>
    </div>

    <footer>
      This payslip is system-generated by NEXTPRIME HRMS & PAYROLL SOFTWARE.
    </footer>
  </div>

  <script>
    const employees = {
      "1": {
        employee: { name: "Mahedi Hasan", id: "1", department: "IT", designation: "Software Engineer" },
        payment: { payDate: "2025-09-30", bank: "BRAC Bank", account: "0123456789", month: "July 2025" },
        earnings: [
          { desc: "Basic Salary", amount: 55000 },
          { desc: "House Rent", amount: 10000 },
          { desc: "Medical Allowance", amount: 2000.00 }
        ],
        deductions: [
          { desc: "Tax", amount: 1000 },
          { desc: "PF ", amount: 2000}
        ]
      },
      "2": {
        employee: { name: "Jannatul Ferdous", id: "2", department: "Finance", designation: "Accountant" },
        payment: { payDate: "2025-09-30", bank: "DBBL", account: "123456789", month: "July 2025" },
        earnings: [
          { desc: "Basic Salary", amount: 45000 },
          { desc: "Bonus", amount: 5000 }
        ],
        deductions: [
          { desc: "Tax", amount: 1000},
          { desc: "PF ", amount: 2000}
        ]
      },
      "3": {
        employee: { name: "Hasan Mahmud", id: "3", department: "Sales", designation: "Sales Executive" },
        payment: { payDate: "2025-09-30", bank: "City Bank", account: "7788990011", month: "July 2025" },
        earnings: [
          { desc: "Basic Salary", amount: 30000 },
          { desc: "Commission", amount: 7000 }
        ],
        deductions: [
          { desc: "Loan", amount: 2000 }
        ]
      }
    };

    function showPayslip() {
      const empId = document.getElementById("employeeSelect").value;
      if (!empId || !employees[empId]) {
        alert("Please select a valid employee.");
        return;
      }

      // Hide selector and show payslip container
      document.getElementById("employeeSelection").style.display = "none";
      document.getElementById("payslipContainer").style.display = "block";

      const data = employees[empId];

      // Fill employee info
      document.getElementById("empName").textContent = data.employee.name;
      document.getElementById("empId").textContent = data.employee.id;
      document.getElementById("empDept").textContent = data.employee.department;
      document.getElementById("empDesig").textContent = data.employee.designation;

      // Fill payment info
      document.getElementById("payDate").textContent = data.payment.payDate;
      document.getElementById("bankName").textContent = data.payment.bank;
      document.getElementById("bankAcc").textContent = data.payment.account;
      document.getElementById("salaryMonth").textContent = data.payment.month;

      // Clear and populate earnings and deductions tables
      const eBody = document.querySelector("#earningsTable tbody");
      const dBody = document.querySelector("#deductionsTable tbody");
      eBody.innerHTML = "";
      dBody.innerHTML = "";

      let gross = 0, deduct = 0;
      data.earnings.forEach(item => {
        eBody.innerHTML += `<tr><td>${item.desc}</td><td>${item.amount.toFixed(2)}</td></tr>`;
        gross += item.amount;
      });

      data.deductions.forEach(item => {
        dBody.innerHTML += `<tr><td>${item.desc}</td><td>${item.amount.toFixed(2)}</td></tr>`;
        deduct += item.amount;
      });

      document.getElementById("grossSalary").textContent = `৳${gross.toFixed(2)}`;
      document.getElementById("totalDeductions").textContent = `৳${deduct.toFixed(2)}`;
      document.getElementById("netPay").textContent = `৳${(gross - deduct).toFixed(2)}`;
    }
  </script>
</body>
</html>

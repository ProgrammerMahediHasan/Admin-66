<?php
// ---------------- FILTER INPUT ----------------
$selectedYear = $_GET['year'] ?? '';
$selectedEmp  = $_GET['emp_id'] ?? '';

// Fetch All Employees
$employees = Employee::all();

// 🔒 DEFAULT: no data
if (!empty($selectedYear) || !empty($selectedEmp)) {
    $leave_assign_all = LeaveAssign::all();
} else {
    $leave_assign_all = [];
}

// ---------------- APPLY FILTER ----------------
$leave_assign = array_filter($leave_assign_all, function($la) use ($selectedYear, $selectedEmp) {

    if ($selectedYear != '' && $la->year != $selectedYear) {
        return false;
    }

    if ($selectedEmp != '' && $la->emp_id != $selectedEmp) {
        return false;
    }

    return true;
});
?>

<!DOCTYPE html>
<html>
<head>
    <title>Remaining Leave Report</title>

    <style>
        body { font-family: Arial; background: #f5f7fa; padding: 20px; }
        h2 { text-align: center; color:#0d6efd; }

        .filter-box {
            background:#fff;
            padding:15px;
            border-radius:8px;
            margin-bottom:20px;
        }

        table {
            width:100%;
            border-collapse: collapse;
            background:#fff;
        }

        th, td {
            border:1px solid #ddd;
            padding:10px;
            text-align:center;
        }

        th {
            background:#0d6efd;
            color:#fff;
        }

        tr:nth-child(even){ background:#f2f2f2; }
    </style>
</head>

<body>

<h2>Remaining Leave Report</h2>
<br>
<br>

<!-- ================= FILTER FORM ================= -->
<form method="GET" class="filter-box">

    <b>Year:</b>
    <select name="year">
        <option value="">All Year</option>
        <?php for($y = date('Y'); $y >= 2020; $y--): ?>
            <option value="<?= $y ?>" <?= ($selectedYear == $y) ? 'selected' : '' ?>>
                <?= $y ?>
            </option>
        <?php endfor; ?>
    </select>

    &nbsp;&nbsp;

    <b>Employee:</b>
    <select name="emp_id">
        <option value="">All Employee</option>
        <?php foreach($employees as $emp): ?>
            <option value="<?= $emp->id ?>" <?= ($selectedEmp == $emp->id) ? 'selected' : '' ?>>
                <?= htmlspecialchars($emp->name) ?>
            </option>
        <?php endforeach; ?>
    </select>

    &nbsp;&nbsp;

    <button type="submit">Search</button>

</form>

<!-- ================= TABLE ================= -->
<table>
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Leave Type</th>
            <th>Allowed</th>
            <th>Used</th>
            <th>Remaining</th>
            <th>Year</th>
        </tr>
    </thead>

    <tbody>

    <?php if(!empty($leave_assign)): ?>
        <?php foreach($leave_assign as $la): ?>
        <?php
            $employee  = Employee::find($la->emp_id);
            $leaveType = LeaveType::find($la->leave_type_id);

            $remaining = $la->allow_days - $la->used_days;
        ?>
        <tr>
            <td><?= htmlspecialchars($employee->name ?? 'Unknown') ?></td>
            <td><?= htmlspecialchars($leaveType->leave_name ?? 'Unknown') ?></td>
            <td><?= $la->allow_days ?></td>
            <td><?= $la->used_days ?></td>
            <td><?= $remaining ?></td>
            <td><?= $la->year ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6">No data found</td>
        </tr>
    <?php endif; ?>

    </tbody>
</table>

</body>
</html>

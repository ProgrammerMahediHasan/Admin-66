<?php
// ---------------- FILTER INPUT ----------------
$selectedYear = $_GET['year'] ?? '';
$selectedEmp  = $_GET['emp_id'] ?? '';

// Fetch All Employees
$employees = Employee::all();

// 🔒 DEFAULT: no data
if (!empty($selectedYear) || !empty($selectedEmp)) {
    $leave_assign_all = LeaveAssign::all();
} else {
    $leave_assign_all = [];
}

// ---------------- APPLY FILTER ----------------
$leave_assign = array_filter($leave_assign_all, function($la) use ($selectedYear, $selectedEmp) {

    if ($selectedYear != '' && $la->year != $selectedYear) {
        return false;
    }

    if ($selectedEmp != '' && $la->emp_id != $selectedEmp) {
        return false;
    }

    return true;
});
?>

<!DOCTYPE html>
<html>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

body { font-family: 'Poppins', sans-serif; background: #f5f7fa; padding: 20px; }
h2 { text-align: center; color:#0d6efd; font-size:30px; font-weight:500; }

.filter-box {
    background:#fff;
    padding:20px;
    border-radius:10px;
    margin-bottom:25px;
    font-size:16px;
}

.table-responsive { overflow-x:auto; margin-top:20px; }

.table-responsive table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
    font-family:'Poppins',sans-serif;
    background:#fff;
    box-shadow:0 4px 15px rgba(0,0,0,0.08);
}

/* Table header - white border */
.table-responsive table th{
    font-weight:700;
    text-align:center;
    background-color:#1f3d79ff;
    color:#ffffff;
    padding:12px;
    font-size:16px;
    border:1px solid #fff; /* white border */
}

/* Table data - black border */
.table-responsive table td{
    text-align:center;
    vertical-align:middle;
    padding:10px;
    font-size:15px;
    color:#000000;
    word-wrap:break-word;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
    border:1px solid #000; /* black border */
}

.table-responsive table tr:hover{
    background:#f1f5f9;
    transition:.2s;
}

.btn-group{
    display:flex !important;
    justify-content:center;
    gap:6px;
    flex-wrap:nowrap;
}

.btn-group button{
    padding:8px 14px !important;
    font-size:16px !important;
    border-radius:5px;
    border:2px solid #000;
    cursor:pointer;
    color:#fff;
    font-weight:900;
    display:flex;
    align-items:center;
    justify-content:center;
}

.btn-group i{
    font-weight:1000;
}

.btn-primary{ background:#3b82f6; }
.btn-danger{ background:#ef4444; }
.btn-info{ background:#0dcaf0; }

@media(max-width:768px){
    .table-responsive table th,
    .table-responsive table td{
        font-size:14px;
        padding:8px;
    }
    .btn-group button{
        font-size:12px !important;
        width:30px;
        height:30px;
        padding:3px 6px !important;
    }
    .btn-group i{
        font-size:14px;
    }
}
</style>


<body>

<h2>Remaining Leave Report</h2>

<!-- ================= FILTER FORM ================= -->
<form method="GET" class="filter-box">
    <b>Year:</b>
    <select name="year">
        <option value="">All Year</option>
        <?php for($y = date('Y'); $y >= 2020; $y--): ?>
            <option value="<?= $y ?>" <?= ($selectedYear == $y) ? 'selected' : '' ?>>
                <?= $y ?>
            </option>
        <?php endfor; ?>
    </select>

    &nbsp;&nbsp;

    <b>Employee:</b>
    <select name="emp_id">
        <option value="">All Employee</option>
        <?php foreach($employees as $emp): ?>
            <option value="<?= $emp->id ?>" <?= ($selectedEmp == $emp->id) ? 'selected' : '' ?>>
                <?= htmlspecialchars($emp->name) ?>
            </option>
        <?php endforeach; ?>
    </select>

    &nbsp;&nbsp;

    <button type="submit">Search</button>
</form>

<!-- ================= TABLE ================= -->
<div class="table-responsive">
<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Leave Type</th>
            <th>Allowed</th>
            <th>Used</th>
            <th>Remaining</th>
            <th>Year</th>
        </tr>
    </thead>

    <tbody>
    <?php if(!empty($leave_assign)): ?>
        <?php foreach($leave_assign as $la): ?>
        <?php
            $employee  = Employee::find($la->emp_id);
            $leaveType = LeaveType::find($la->leave_type_id);
            $remaining = $la->allow_days - $la->used_days;
        ?>


        <!-- <tr>
            <td><?= htmlspecialchars($employee->name ?? 'Unknown') ?></td>
            <td><?= htmlspecialchars($leaveType->name ?? 'Unknown') ?></td>
            <td><?= $la->allow_days ?></td>
            <td><?= $la->used_days ?></td>
            <td><?= $remaining ?></td>
            <td><?= $la->year ?></td>
        </tr> -->

        <tr>
    <td><?= htmlspecialchars($employee->name ?? 'Unknown') ?></td>
    <td><?= htmlspecialchars($leaveType->name ?? 'Unknown') ?></td>
    <td><?= $la->allow_days ?></td>
    <td><?= $la->used_days ?></td>
    <td style="color: <?= ($remaining < 0) ? 'red' : 'black' ?>;">
        <?= $remaining ?>
    </td>
    <td><?= $la->year ?></td>
</tr>




        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="6">No data found</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

</body>
</html>

<?php
echo Page::title(["title"=>"Create LeaveAssign"]);
echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leaveassign", "text"=>"Manage LeaveAssign"]);
echo Page::context_open();
echo Form::open(["route"=>"leaveassign/save"]);
	echo Form::input(["label"=>"Emp","name"=>"emp_id","table"=>"emps"]);
	echo Form::input(["label"=>"Leave Type","name"=>"leave_type_id","table"=>"leave_types"]);
	echo Form::input(["label"=>"Allow Days","type"=>"text","name"=>"allow_days"]);
	echo Form::input(["label"=>"Used Days","type"=>"text","name"=>"used_days"]);
	echo Form::input(["label"=>"Year","type"=>"text","name"=>"year"]);

echo Form::input(["name"=>"create","class"=>"btn btn-primary offset-2", "value"=>"Save", "type"=>"submit"]);
echo Form::close();
echo Page::context_close();
echo Page::body_close();

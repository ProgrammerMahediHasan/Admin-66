<?php
// echo Page::title(["title" => "Edit Employee"]);
echo Page::body_open();
echo Html::link(["class" => "btn btn-success","route" => "employee","text" => "Back Employee"]);
echo Page::context_open();
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
body { font-family: 'Poppins', sans-serif; background: linear-gradient(120deg, #e8f0ff 0%, #f5f7fa 100%); min-height: 100vh; padding: 40px; }
.form-card { max-width: 950px; margin: 0 auto; background: #fff; border-radius: 18px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); overflow: hidden; animation: fadeUp 0.8s ease; border: 1px solid #e6e9ef; }
.form-header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; padding: 25px 40px; text-align: center; position: relative; }
.form-header::after { content: ""; position: absolute; width: 80px; height: 4px; background: #60a5fa; bottom: 0; left: 50%; transform: translateX(-50%); border-radius: 2px; }
.form-header h2 { margin: 0; font-size: 26px; letter-spacing: 0.5px; font-weight: 600; }
.form-header p { margin-top: 5px; font-size: 14px; opacity: 0.9; }
.form-body { padding: 40px 50px; }
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px 40px; }
.form-group { position: relative; margin-top: 10px; }
.form-group input, .form-group select { width: 100%; padding: 14px 14px 14px 12px; border: 1px solid #d1d5db; border-radius: 10px; background: #f9fafb; font-size: 14px; outline: none; transition: all 0.3s ease; }
.form-group label { position: absolute; top: 14px; left: 14px; color: #777; font-size: 14px; font-weight: 500; transition: all 0.3s ease; pointer-events: none; }
.form-group input:focus + label, .form-group input:not(:placeholder-shown) + label, .form-group select:focus + label, .form-group select:not([value=""]) + label { top: -10px; left: 10px; background: #fff; color: #2563eb; font-size: 12px; padding: 0 5px; }
.form-group input:focus, .form-group select:focus { border-color: #2563eb; box-shadow: 0 0 8px rgba(37,99,235,0.25); background-color: #fff; }
.btn-submit { grid-column: 1 / -1; justify-self: end; padding: 14px 32px; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; border: none; border-radius: 10px; font-weight: 600; font-size: 15px; cursor: pointer; transition: 0.3s ease; box-shadow: 0 5px 15px rgba(37,99,235,0.25); }
.btn-submit:hover { background: linear-gradient(135deg, #1e40af, #1d4ed8); transform: translateY(-2px); box-shadow: 0 8px 20px rgba(37,99,235,0.35); }
@keyframes fadeUp { from { opacity: 0; transform: translateY(25px); } to { opacity: 1; transform: translateY(0); } }
@media (max-width: 768px) { .form-body { padding: 25px 20px; } .form-grid { grid-template-columns: 1fr; gap: 18px; } }
</style>

<div class="form-card">
  <div class="form-header">
    <h2>Edit Employee</h2>
    <p>Update employee details carefully</p>
  </div>
  <div class="form-body">
    <form action="<?=$base_url?>/employee/update" method="post">
      <input type="hidden" name="id" value="<?= $employee->id ?>">
      <div class="form-grid">

        <!-- Full Name -->
        <div class="form-group">
          <input type="text" name="name" id="name" placeholder=" " value="<?= $employee->name ?>" required>
          <label for="name">Full Name</label>
        </div>

        <!-- Department -->
        <div class="form-group">
          <select name="dept_id" id="dept_id" required>
            <option value="">Choose Department</option>
            <?php 
            $depts = Department::getall();
            foreach($depts as $dept){
                $selected = ($dept->id == $employee->dept_id) ? "selected" : "";
                echo "<option value='{$dept->id}' $selected>{$dept->name}</option>";
            }
            ?>
          </select>
          <label for="dept_id">Department</label>
        </div>

        <!-- Designation -->
        <div class="form-group">
          <select name="desig_id" id="desig_id" required>
            <option value="">Choose Designation</option>
            <?php 
            $desigs = Designation::getall();
            foreach($desigs as $desig){
                if($desig->dept_id == $employee->dept_id)
                  {
                    $selected = ($desig->id == $employee->desig_id) ? "selected" : "";
                    echo "<option value='{$desig->id}' $selected>{$desig->name}</option>";
                }
            }
            ?>
          </select>
          <label for="desig_id">Designation</label>
        </div>

        <!-- Email -->
        <div class="form-group">
          <input type="email" name="email" id="email" placeholder=" " value="<?= $employee->email ?>" required>
          <label for="email">Email</label>
        </div>

        <!-- Phone -->
        <div class="form-group">
          <input type="text" name="phone" id="phone" placeholder=" " value="<?= $employee->phone ?>" required>
          <label for="phone">Phone</label>
        </div>

        <!-- Gender -->
        <div class="form-group">
          <select name="gender" id="gender" required>
            <?php
            $genders = ["Male","Female","Other"];
            foreach($genders as $g){
                $selected = ($employee->gender == $g) ? "selected" : "";
                echo "<option value='$g' $selected>$g</option>";
            }
            ?>
          </select>
          <label for="gender">Gender</label>
        </div>

        <!-- Joining Date -->
        <div class="form-group">
          <input type="date" name="joining_date" id="joining_date" placeholder=" " value="<?= $employee->joining_date ?>" required>
          <label for="joining_date">Joining Date</label>
        </div>

        <!-- Status -->
        <div class="form-group">
          <select name="status" id="status" required>
            <?php
            $statuses = ["Active","Inactive"];
            foreach($statuses as $s){
                $selected = ($employee->status == $s) ? "selected" : "";
                echo "<option value='$s' $selected>$s</option>";
            }
            ?>
          </select>
          <label for="status">Status</label>
        </div>

        <!-- Submit Button -->
        <button type="submit" name="update" value="update" class="btn-submit">Update</button>
      </div>
    </form>
  </div>
</div>

<script>
// Dynamic designation dropdown on department change
document.getElementById("dept_id").addEventListener("change", function(){
    var dept_id = this.value;
    var desigDropdown = document.getElementById("desig_id");
    desigDropdown.innerHTML = "<option value=''>Choose Designation</option>";
    if(dept_id !== ""){
        fetch("<?=$base_url?>/api/designation/find_by_dep_id?id=" + dept_id)
        .then(res => res.json())
        .then(data => {
            data.forEach(function(desig){
                var option = document.createElement("option");
                option.value = desig.id;
                option.text = desig.name;
                desigDropdown.appendChild(option);
            });
        })
        .catch(err => console.error(err));
    }
});
</script>

<?php
echo Page::context_close();
echo Page::body_close();
?>

<?php // Your PHP code & backend logic remain unchanged ?>
<!-- ✅ Professional & Dynamic Template -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(120deg, #e8f0ff 0%, #f5f7fa 100%);
    min-height: 100vh;
    padding: 40px;
}

/* === Card Container === */
.form-card {
    max-width: 950px;
    margin: 0 auto;
    background: #fff;
    border-radius: 18px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.08);
    overflow: hidden;
    animation: fadeUp 0.8s ease;
    border: 1px solid #e6e9ef;
}

/* === Header === */
.form-header {
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: #fff;
    padding: 25px 40px;
    text-align: center;
    position: relative;
}
.form-header::after {
    content: "";
    position: absolute;
    width: 80px;
    height: 4px;
    background: #60a5fa;
    bottom: 0;
    left: 50%;
    transform: translateX(-50%);
    border-radius: 2px;
}
.form-header h2 {
    margin: 0;
    font-size: 26px;
    letter-spacing: 0.5px;
    font-weight: 600;
}
.form-header p {
    margin-top: 5px;
    font-size: 14px;
    opacity: 0.9;
}

/* === Form Body === */
.form-body {
    padding: 40px 50px;
}
.form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 24px 40px;
}

/* === Floating Label Input === */
.form-group {
    position: relative;
    margin-top: 10px;
}
.form-group input, .form-group select {
    width: 100%;
    padding: 14px 14px 14px 12px;
    border: 1px solid #d1d5db;
    border-radius: 10px;
    background: #f9fafb;
    font-size: 14px;
    outline: none;
    transition: all 0.3s ease;
}
.form-group label {
    position: absolute;
    top: 14px;
    left: 14px;
    color: #777;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.3s ease;
    pointer-events: none;
}
/* Float label up on focus or filled */
.form-group input:focus + label,
.form-group input:not(:placeholder-shown) + label,
.form-group select:focus + label,
.form-group select:not([value=""]) + label {
    top: -10px;
    left: 10px;
    background: #fff;
    color: #2563eb;
    font-size: 12px;
    padding: 0 5px;
}
.form-group input:focus,
.form-group select:focus {
    border-color: #2563eb;
    box-shadow: 0 0 8px rgba(37,99,235,0.25);
    background-color: #fff;
}

/* === Submit Button === */
.btn-submit {
    grid-column: 1 / -1;
    justify-self: end;
    padding: 14px 32px;
    background: linear-gradient(135deg, #2563eb, #1d4ed8);
    color: #fff;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    font-size: 15px;
    cursor: pointer;
    transition: 0.3s ease;
    box-shadow: 0 5px 15px rgba(37,99,235,0.25);
}
.btn-submit:hover {
    background: linear-gradient(135deg, #1e40af, #1d4ed8);
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(37,99,235,0.35);
}

/* === Animation === */
@keyframes fadeUp {
    from { opacity: 0; transform: translateY(25px); }
    to { opacity: 1; transform: translateY(0); }
}

/* === Responsive === */
@media (max-width: 768px) {
    .form-body { padding: 25px 20px; }
    .form-grid { grid-template-columns: 1fr; gap: 18px; }
}
</style>

<!-- === HTML Template === -->
<div class="form-card">
  <div class="form-header">
    <h2>Employee Registration</h2>
    <p>Fill in employee details carefully</p>
  </div>
  <div class="form-body">
    <form action="<?=$base_url?>/employee/save" method="post">
      <div class="form-grid">
        <!-- Full Name -->
        <div class="form-group">
          <input type="text" name="name" id="name" placeholder=" " required>
          <label for="name">Full Name</label>
        </div>

        <!-- Department -->
        <div class="form-group">
          <select name="dept_id" id="dept" required>
            <?php 
              $depts= Department::getall();
              foreach($depts as $value) {
                echo "<option value='{$value->id}'>{$value->name}</option>";
              }
            ?>
          </select>
          <label for="dept_id">Department</label>
        </div>

        <!-- Designation -->
        <div class="form-group">
          <select name="desig_id" id="desigdfdef" required>
            <?php 
              $desig= Designation::getall();
              foreach($desig as $value) {
                echo "<option value='{$value->id}'>{$value->name}</option>";
              }
            ?>
          </select>
          <label for="desig_id">Designation</label>
        </div>

        <!-- Email -->
        <div class="form-group">
          <input type="text" name="email" id="email" placeholder=" " required>
          <label for="email">Email</label>
        </div>

        <!-- Phone -->
        <div class="form-group">
          <input type="text" name="phone" id="phone" placeholder=" " required>
          <label for="phone">Phone</label>
        </div>

        <!-- Basic Salary -->
        <div class="form-group">
          <input type="text" name="basic_salary" id="basic_salary" placeholder=" " required>
          <label for="basic_salary">Basic Salary</label>
        </div>

        <!-- Gender -->
        <div class="form-group">
          <select name="gender" id="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          <label for="gender">Gender</label>
        </div>

        <!-- Joining Date -->
        <div class="form-group">
          <input type="date" name="joining_date" id="joining_date" placeholder=" " required>
          <label for="joining_date">Joining Date</label>
        </div>

        <!-- Status -->
        <div class="form-group">
          <select name="status" id="status" required>
            <option value="">Select Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
          <label for="status">Status</label>
        </div>

        <!-- Submit Button -->
        <button type="submit" name="btn_save" value="save" class="btn-submit">💾 Save Employee</button>
      </div>
    </form>
  </div>
</div>

<!-- === jQuery Script (Unchanged Functional Code) === -->
<script>
$(document).ready(function(){
    // Load Departments
    $.ajax({
        url: "http://localhost/PHP_Converted/admin/api/department/department",
        type: "GET",
        success: function(res){
            let dept = JSON.parse(res);
            let $deptDropdown = $("#dept_id");
            $deptDropdown.find('option:not(:first)').remove();
            if(Array.isArray(dept)){
                $.each(dept, function(index, d){
                    $deptDropdown.append($('<option></option>').val(d.id).text(d.name));
                });
            } else {
                $deptDropdown.append($('<option></option>').val(dept.id).text(dept.name));
            }
        }
    });

    // Load Designations based on Department
    $("#dept_id").on("change", function(){
        let dept_id = $(this).val();
        let $desigDropdown = $("#desig_id");
        $desigDropdown.find('option:not(:first)').remove();
        if(dept_id){
            $.ajax({
                url: "http://localhost/PHP_Converted/admin/api/designation/find_by_dep_id",
                type: "GET",
                data: { id: dept_id },
                success: function(res){
                    let designations = JSON.parse(res);
                    $.each(designations, function(index, desig){
                        $desigDropdown.append($('<option></option>').val(desig.id).text(desig.name));
                    });
                }
            });
        }
    });
});
</script>

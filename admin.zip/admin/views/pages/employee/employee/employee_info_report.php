<?php
echo Page::body_open();
echo Page::context_open();

global $db, $tx;

// Fetch all employees for dropdown
$allEmployees = $db->query("SELECT id, name FROM {$tx}employees ORDER BY id ASC");

// Handle filter by employee
$emp_id = $_GET['emp_id'] ?? '';
$filter_sql = '';
if (!empty($emp_id)) {
    $emp_id = (int)$emp_id;
    $filter_sql = "WHERE e.id = $emp_id";
}

// Fetch employee(s) info
$employees = $db->query("
    SELECT e.id, e.name, d.name AS department, ds.name AS designation, e.gender, e.email, e.phone, e.basic_salary, e.status, e.joining_date
    FROM {$tx}employees e
    LEFT JOIN {$tx}department d ON e.dept_id = d.id
    LEFT JOIN {$tx}designations ds ON e.desig_id = ds.id
    $filter_sql
    ORDER BY e.id ASC
");
?>

<!-- Page Title -->
<div class="text-center my-4">
    <h2 class="fw-bold text-primary mb-1" style="font-size:1.35rem;">Employee Personal Information Report</h2>
    <!-- <p class="text-muted small" style="font-size:0.88rem;">Detailed information of employees</p> -->
</div>

<!-- Employee Filter Form -->
<div class="mb-3 d-flex justify-content-start">
    <form method="GET" class="d-flex align-items-center" style="font-size:0.85rem;">
        <label for="emp_id" class="me-2 fw-bold"><h6>Choose:</h6></label>

        <select name="emp_id" id="emp_id" class="form-select me-2" style="font-size:0.85rem; padding:4px 25px;">
            <option value="">All Employees</option>
            <?php while($row = $allEmployees->fetch_assoc()): ?>
                <option value="<?php echo $row['id']; ?>" <?php echo ($emp_id == $row['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($row['name']); ?>
                </option>
            <?php endwhile; ?>
        </select>
        <button type="submit" class="btn btn-primary btn-lg" style="font-size:0.75rem; padding:3px 50px;">View Report</button>
    </form>
</div>

<!-- Report Card -->
<div class="container-fluid px-2">
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
        <div class="card-header bg-gradient bg-primary text-white py-2">
            <h5 class="mb-0" style="font-size:0.9rem;"><i class="bi bi-people-fill"></i> Employees</h5>
        </div>

        <div class="card-body bg-light p-2" style="background-color: #f8f9fa;">
            <div class="table-responsive">
                <table class="table table-bordered align-middle text-center table-striped table-hover mb-0" 
                       style="table-layout: auto; width: 100%; font-size:0.85rem;">
                    <thead style="background-color: #0056b3; color: #ffffff; font-size:0.88rem;">
                       <tr>
                        <th style="font-weight:bold;">ID</th>
                        <th style="min-width:200px; font-weight:bold;">Name</th>
                        <th style="font-weight:bold;">Department</th>
                        <th style="font-weight:bold;">Designation</th>
                        <th style="font-weight:bold;">Gender</th>
                        <th style="min-width:220px; font-weight:bold;">Email</th>
                        <th style="font-weight:bold;">Phone</th>
                        <th style="font-weight:bold;">Basic Salary</th>
                        <th style="font-weight:bold;">Status</th>
                        <th style="min-width:130px; font-weight:bold;">Joining Date</th>
                        </tr>

                    </thead>
                    <tbody>
                        <?php if($employees->num_rows > 0): ?>
                            <?php while($row = $employees->fetch_assoc()): ?>
                                <tr style="font-size:0.85rem;">
                                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                                    <td style="min-width:200px;"><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['department'] ?? "N/A"); ?></td>
                                    <td><?php echo htmlspecialchars($row['designation'] ?? "N/A"); ?></td>
                                    <td><?php echo htmlspecialchars($row['gender']); ?></td>
                                    <td style="word-break: break-word; min-width:220px;"><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo number_format($row['basic_salary'], 2); ?></td>
                                    <td>
                                        <?php
                                            $status_class = strtolower($row['status']) === 'active' ? 'bg-success' : 'bg-danger';
                                            echo "<span class='badge {$status_class} text-white' style='font-size:0.78rem;'>"
                                                 . ucfirst($row['status']) . "</span>";
                                        ?>
                                    </td>
                                    <td style="min-width:130px;"><?php echo date("d M Y", strtotime($row['joining_date'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted py-2" style="font-size:0.78rem;">
                                    <i class="bi bi-info-circle"></i> No employees found
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
echo Page::context_close();
echo Page::body_close();
?>

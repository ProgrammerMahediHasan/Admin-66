<?php
echo Page::title(["title"=>"Edit LeavePolicy"]);
echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leavepolicy", "text"=>"Manage LeavePolicy"]);
echo Page::context_open();
echo Form::open(["route"=>"leavepolicy/update"]);
	echo Form::input(["label"=>"Id","type"=>"hidden","name"=>"id","value"=>"$leavepolicy->id"]);
	echo Form::input(["label"=>"Leave Type","type"=>"text","name"=>"leave_type","value"=>"$leavepolicy->leave_type"]);
	echo Form::input(["label"=>"Days Allowed","type"=>"text","name"=>"days_allowed","value"=>"$leavepolicy->days_allowed"]);
	echo Form::input(["label"=>"Approval Required","type"=>"textarea","name"=>"approval_required","value"=>"$leavepolicy->approval_required"]);
	echo Form::input(["label"=>"Notes","type"=>"textarea","name"=>"notes","value"=>"$leavepolicy->notes"]);

echo Form::input(["name"=>"update","class"=>"btn btn-success offset-2" , "value"=>"Save Chanage", "type"=>"submit"]);
echo Form::close();
echo Page::context_close();
echo Page::body_close();

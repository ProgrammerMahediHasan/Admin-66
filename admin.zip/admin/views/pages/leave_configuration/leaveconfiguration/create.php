<?php
echo Page::title(["title" => "Create Leave Configuration"]);
echo Page::body_open();
echo Html::link([
    "class" => "btn btn-success mb-3",
    "route" => "leaveconfiguration",
    "text" => "← Back to Manage Leave Configuration"
]);
echo Page::context_open();
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
body { font-family: 'Poppins', sans-serif; padding: 20px; background: #f5f7fa; }
.form-card { max-width: 700px; margin: 0 auto; background: #fff; border-radius: 18px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); padding: 30px; }
.form-header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; padding: 20px; text-align: center; border-radius: 12px 12px 0 0; }
.form-header h2 { margin: 0; }
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 20px; }
.form-group { position: relative; }
.form-group label { position: absolute; top: 14px; left: 12px; color: #555; font-size: 14px; pointer-events: none; transition: 0.3s; background: #fff; padding: 0 5px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 14px 12px; border: 1px solid #ccc; border-radius: 8px; font-size: 14px; outline: none; }
.form-group input:focus + label, .form-group select:focus + label, .form-group textarea:focus + label,
.form-group input:not(:placeholder-shown) + label, .form-group select:not([value=""]) + label, .form-group textarea:not(:placeholder-shown) + label { top: -10px; left: 8px; font-size: 12px; color: #2563eb; }
.btn-submit { grid-column: 1 / -1; justify-self: center; padding: 14px 36px; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; }
.btn-submit:hover { background: linear-gradient(135deg, #1e40af, #1d4ed8); }
@media(max-width:768px){.form-grid{grid-template-columns:1fr;}}
</style>

<div class="form-card">
  <div class="form-header">
    <h2>Create Leave Configuration</h2>
  </div>
  <form action="<?=$base_url?>/leaveconfiguration/save" method="post">
    <div class="form-grid">

      <div class="form-group">
        <input type="text" name="leave_type" placeholder=" " required>
        <label>Leave Type</label>
      </div>

      <div class="form-group">
        <input type="number" name="total_days" placeholder=" " required>
        <label>Total Days (Per Year)</label>
      </div>

      <div class="form-group">
        <select name="carry_forward" required>
          <option value="">Choose Option</option>
          <option value="1">Yes</option>
          <option value="0">No</option>
        </select>
        <label>Carry Forward</label>
      </div>

      <div class="form-group">
        <textarea name="description" rows="3" placeholder=" "></textarea>
        <label>Description</label>
      </div>

      <div class="form-group">
        <select name="status" required>
          <option value="">Choose Status</option>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
        <label>Status</label>
      </div>

      <button type="submit" name="create" class="btn-submit">Save Leave Configuration</button>
    </div>
  </form>
</div>

<?php
echo Page::context_close();
echo Page::body_close();
?>

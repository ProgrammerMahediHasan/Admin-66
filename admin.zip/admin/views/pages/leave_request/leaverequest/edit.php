<?php
echo Page::title(["title"=>"Edit LeaveRequest"]);
echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leaverequest", "text"=>"Manage LeaveRequest"]);
echo Page::context_open();
echo Form::open(["route"=>"leaverequest/update"]);
	echo Form::input(["label"=>"Leave","name"=>"leave_id","table"=>"leaves","value"=>"$leaverequest->leave_id"]);
	echo Form::input(["label"=>"Emp","name"=>"emp_id","table"=>"emps","value"=>"$leaverequest->emp_id"]);
	echo Form::input(["label"=>"Leave Type","type"=>"text","name"=>"leave_type","value"=>"$leaverequest->leave_type"]);
	echo Form::input(["label"=>"Start Date","type"=>"text","name"=>"start_date","value"=>"$leaverequest->start_date"]);
	echo Form::input(["label"=>"End Date","type"=>"text","name"=>"end_date","value"=>"$leaverequest->end_date"]);
	echo Form::input(["label"=>"Reason","type"=>"textarea","name"=>"reason","value"=>"$leaverequest->reason"]);
	echo Form::input(["label"=>"Status","type"=>"text","name"=>"status","value"=>"$leaverequest->status"]);
	echo Form::input(["label"=>"Approver","name"=>"approver_id","table"=>"approvers","value"=>"$leaverequest->approver_id"]);
	echo Form::input(["label"=>"Applied On","type"=>"date","name"=>"applied_on","value"=>"$leaverequest->applied_on"]);

echo Form::input(["name"=>"update","class"=>"btn btn-success offset-2" , "value"=>"Save Chanage", "type"=>"submit"]);
echo Form::close();
echo Page::context_close();
echo Page::body_close();

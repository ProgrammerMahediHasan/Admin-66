<?php
echo Page::title(["title" => "Edit Leave Request"]);
echo Page::body_open();
echo Html::link([
    "class" => "btn btn-success mb-3",
    "route" => "leaverequest",
    "text" => "← Back Previous Page"
]);
echo Page::context_open();

// ------------------ Fetch Employees ------------------
global $db, $tx;
$employees = [];
$emp_result = $db->query("SELECT id, name FROM {$tx}employees ORDER BY name ASC");
if($emp_result){
    while($row = $emp_result->fetch_assoc()){
        $employees[$row['id']] = $row['name'];
    }
}

// Leave Types
$leave_types = ["Casual Leave", "Sick Leave", "Earned Leave", "Unpaid Leave"];
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

body { font-family: 'Poppins', sans-serif; background: #f5f7fa; padding: 20px; }
.form-card { max-width: 900px; margin: 0 auto; background: #fff; border-radius: 18px; box-shadow: 0 8px 25px rgba(0,0,0,0.08); padding: 30px; }
.form-header { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; padding: 20px; text-align: center; border-radius: 12px 12px 0 0; }
.form-header h2 { margin: 0; }
.form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 20px; }
.form-group { position: relative; }
.form-group label { position: absolute; top: 14px; left: 12px; color: #555; font-size: 14px; pointer-events: none; transition: 0.3s; background: #fff; padding: 0 5px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; padding: 14px 12px; border: 1px solid #ccc; border-radius: 8px; font-size: 14px; outline: none; }
.form-group input:focus + label, .form-group select:focus + label, .form-group textarea:focus + label,
.form-group input:not(:placeholder-shown) + label, .form-group select:not([value=""]) + label, .form-group textarea:not(:placeholder-shown) + label { top: -10px; left: 8px; font-size: 12px; color: #2563eb; }
.btn-submit { grid-column: 1 / -1; justify-self: center; padding: 14px 36px; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: #fff; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; }
.btn-submit:hover { background: linear-gradient(135deg, #1e40af, #1d4ed8); }
@media(max-width:768px){.form-grid{grid-template-columns:1fr;}}
</style>

<div class="form-card">
  <div class="form-header">
    <h2>Edit Leave Request</h2>
  </div>
  <form action="<?=$base_url?>/leaverequest/update" method="post" enctype="multipart/form-data">
    <div class="form-grid">

      <input type="hidden" name="id" value="<?=$leaverequest->id?>">

      <!-- Employee -->
      <div class="form-group">
        <select name="emp_id" required>
          <option value="">Select Employee</option>
          <?php foreach($employees as $id => $name){ ?>
            <option value="<?=$id?>" <?= ($leaverequest->emp_id==$id)?'selected':'' ?>><?=$name?></option>
          <?php } ?>
        </select>
        <label>Employee</label>
      </div>

      <!-- Leave Type -->
      <div class="form-group">
        <select name="leave_type" required>
          <option value="">Choose Leave Type</option>
          <?php foreach($leave_types as $type){ ?>
            <option value="<?=$type?>" <?= ($leaverequest->leave_type==$type)?'selected':'' ?>><?=$type?></option>
          <?php } ?>
        </select>
        <label>Leave Type</label>
      </div>

      <!-- From Date -->
      <div class="form-group">
        <input type="date" name="from_date" id="from_date" value="<?=$leaverequest->from_date?>" required>
        <label>From Date</label>
      </div>

      <!-- To Date -->
      <div class="form-group">
        <input type="date" name="to_date" id="to_date" value="<?=$leaverequest->to_date?>" required>
        <label>To Date</label>
      </div>

      <!-- Total Days -->
      <div class="form-group">
        <input type="number" name="total_days" id="total_days" value="<?=$leaverequest->total_days?>" readonly required>
        <label>Total Days</label>
      </div>

      <!-- Reason -->
      <div class="form-group">
        <textarea name="reason" rows="3" required><?=$leaverequest->reason?></textarea>
        <label>Reason</label>
      </div>

      <!-- Attachment -->
      <div class="form-group">
        <input type="file" name="attachment">
        <label>Attachment</label>
      </div>

      <!-- Status -->
      <div class="form-group">
        <select name="status" required>
          <option value="Pending" <?= ($leaverequest->status=='Pending')?'selected':'' ?>>Pending</option>
          <option value="Approved" <?= ($leaverequest->status=='Approved')?'selected':'' ?>>Approved</option>
          <option value="Rejected" <?= ($leaverequest->status=='Rejected')?'selected':'' ?>>Rejected</option>
        </select>
        <label>Status</label>
      </div>

      <!-- Approved By -->
      <div class="form-group">
        <input type="text" name="approved_by" value="<?=$leaverequest->approved_by?>">
        <label>Approved By</label>
      </div>

      <!-- Paid Leave -->
      <div class="form-group">
        <select name="paid_leave" required>
          <option value="Yes" <?= ($leaverequest->paid_leave=='Yes')?'selected':'' ?>>Yes</option>
          <option value="No" <?= ($leaverequest->paid_leave=='No')?'selected':'' ?>>No</option>
        </select>
        <label>Paid Leave</label>
      </div>

      <!-- Submit Button -->
      <button type="submit" class="btn-submit">💾 Save Changes</button>

    </div>
  </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function(){
    const fromDate = document.getElementById("from_date");
    const toDate = document.getElementById("to_date");
    const totalDays = document.getElementById("total_days");

    function calculateDays(){
        if(fromDate.value && toDate.value){
            const from = new Date(fromDate.value);
            const to = new Date(toDate.value);
            const diffTime = to - from;
            const diffDays = Math.floor(diffTime / (1000*60*60*24)) + 1;
            totalDays.value = diffDays > 0 ? diffDays : 0;
        }
    }

    fromDate.addEventListener("change", calculateDays);
    toDate.addEventListener("change", calculateDays);
});
</script>

<?php
echo Page::context_close();
echo Page::body_close();
?>

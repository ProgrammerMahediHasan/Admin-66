<?php
echo Page::title(["title" => "Leave Report"]);
echo Page::body_open();

global $db, $tx;

// ✅ 1️⃣ Fetch all employees
$employees = [];
$result_emp = $db->query("SELECT id, name FROM {$tx}employees ORDER BY name ASC");
while($row = $result_emp->fetch_assoc()){
    $employees[$row['id']] = $row['name'];
}

// ✅ 2️⃣ Fetch only ACTIVE leave types from configuration
$leave_config = [];
$result_config = $db->query("SELECT leave_type, total_days FROM {$tx}leave_configuration WHERE status='Active'");
while($row = $result_config->fetch_assoc()){
    $leave_config[$row['leave_type']] = $row['total_days'];
}

// ✅ 3️⃣ Handle filters
$selected_emp = isset($_GET['emp_id']) ? $_GET['emp_id'] : '';
$selected_leave_type = isset($_GET['leave_type']) ? $_GET['leave_type'] : '';

// ✅ 4️⃣ Filter form
echo "<div class='container mt-4'>";
echo "<form method='GET' class='row g-3 mb-4'>";

// --- Employee Filter ---
echo "<div class='col-md-4'>";
echo "<label><b>Filter by Employee:</b></label>";
echo "<select name='emp_id' class='form-select'>";
echo "<option value=''>Choose Employee</option>";
foreach($employees as $id => $name){
    $sel = ($selected_emp == $id) ? 'selected' : '';
    echo "<option value='{$id}' {$sel}>{$name}</option>";
}
echo "</select>";
echo "</div>";

// --- Leave Type Filter ---
echo "<div class='col-md-4'>";
echo "<label><b>Filter by Leave Type:</b></label>";
echo "<select name='leave_type' class='form-select'>";
echo "<option value=''>Choose Leave Type</option>";
foreach($leave_config as $type => $max){
    $sel = ($selected_leave_type == $type) ? 'selected' : '';
    echo "<option value='{$type}' {$sel}>{$type}</option>";
}
echo "</select>";
echo "</div>";

// --- Submit Button ---
echo "<div class='col-md-2 align-self-end'>";
echo "<button type='submit' class='btn btn-primary w-100'>Filter</button>";
echo "</div>";

echo "</form>";

// ✅ Only show report if any filter is applied
if (!empty($selected_emp) || !empty($selected_leave_type)) {

    echo "<table class='table table-bordered table-striped'>";
    echo "<thead class='table-dark'>
            <tr>
                <th>Employee</th>
                <th>Leave Type</th>
                <th class='text-center'>Total Leave</th>
                <th class='text-center'>Used Leave</th>
                <th class='text-center'>Remaining Leave</th>
            </tr>
          </thead><tbody>";

    // ✅ Determine which employees to loop through
    $emp_list = (!empty($selected_emp)) ? [$selected_emp => $employees[$selected_emp]] : $employees;

    foreach($emp_list as $emp_id => $emp_name){

        $conditions = "WHERE emp_id = $emp_id AND status='Approved'";
        if(!empty($selected_leave_type)){
            $conditions .= " AND leave_type='{$selected_leave_type}'";
        }

        // ✅ Get approved leave data
        $approved_leave = [];
        $res_leave = $db->query("
            SELECT leave_type, SUM(total_days) AS used_leave 
            FROM {$tx}leave_request 
            $conditions
            GROUP BY leave_type
        ");
        while($row = $res_leave->fetch_assoc()){
            $approved_leave[$row['leave_type']] = $row['used_leave'];
        }

        // ✅ Show data for all or selected leave type
        foreach($leave_config as $type => $max){
            if(!empty($selected_leave_type) && $type != $selected_leave_type) continue;

            $used = isset($approved_leave[$type]) ? $approved_leave[$type] : 0;
            $remaining = $max - $used;

            echo "<tr>
                    <td>{$emp_name}</td>
                    <td>{$type}</td>
                    <td class='text-center'>{$max}</td>
                    <td class='text-center text-danger fw-bold'>{$used}</td>
                    <td class='text-center text-success fw-bold'>{$remaining}</td>
                  </tr>";
        }
    }

    echo "</tbody></table>";

} else {
    echo "<div class='alert alert-info mt-3'>Please select at least one filter to view leave report.</div>";
}

echo "</div>"; // container end
echo Page::body_close();
?>

<?php
echo Page::title(["title"=>"Create LeaveRequest"]);
echo Page::body_open();
echo Html::link(["class"=>"btn btn-success", "route"=>"leaverequest", "text"=>"Manage LeaveRequest"]);
echo Page::context_open();
echo Form::open(["route"=>"leaverequest/save"]);
	echo Form::input(["label"=>"Leave","name"=>"leave_id","table"=>"leaves"]);
	echo Form::input(["label"=>"Emp","name"=>"emp_id","table"=>"emps"]);
	echo Form::input(["label"=>"Leave Type","type"=>"text","name"=>"leave_type"]);
	echo Form::input(["label"=>"Start Date","type"=>"text","name"=>"start_date"]);
	echo Form::input(["label"=>"End Date","type"=>"text","name"=>"end_date"]);
	echo Form::input(["label"=>"Reason","type"=>"textarea","name"=>"reason"]);
	echo Form::input(["label"=>"Status","type"=>"text","name"=>"status"]);
	echo Form::input(["label"=>"Approver","name"=>"approver_id","table"=>"approvers"]);
	echo Form::input(["label"=>"Applied On","type"=>"date","name"=>"applied_on"]);

echo Form::input(["name"=>"create","class"=>"btn btn-primary offset-2", "value"=>"Save", "type"=>"submit"]);
echo Form::close();
echo Page::context_close();
echo Page::body_close();

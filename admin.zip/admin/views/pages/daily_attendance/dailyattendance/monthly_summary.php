<?php
// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "hrm";

$db = new mysqli($host, $user, $pass, $dbname);
if($db->connect_error){
    die("Connection failed: " . $db->connect_error);
}

// Month & Year
$month = isset($_GET['month']) ? $_GET['month'] : date('m');
$year = isset($_GET['year']) ? $_GET['year'] : date('Y');

// Fetch summary per employee
$query = "
SELECT 
    e.id as emp_id,
    e.name as emp_name,
    SUM(CASE WHEN LOWER(d.status)='present' THEN 1 ELSE 0 END) as total_attendance,
    SUM(COALESCE(d.late_minutes,0)) as total_late,
    SUM(COALESCE(d.overtime_minutes,0)) as total_overtime,
    SUM(CASE WHEN LOWER(d.status)='absent' THEN 1 ELSE 0 END) as total_absent,
    SUM(CASE WHEN LOWER(d.status)='leave' THEN 1 ELSE 0 END) as total_leave
FROM employees e
LEFT JOIN daily_attendance d ON e.id = d.emp_id AND MONTH(d.att_date) = $month AND YEAR(d.att_date) = $year
GROUP BY e.id, e.name
ORDER BY e.name ASC
";

$result = $db->query($query);

$db->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Employees Monthly Summary</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">

<h2 class="mb-4">Employees Monthly Summary Report</h2>

<!-- Month & Year Selection Form -->
<form method="GET" class="row g-3 mb-4">
    <div class="col-md-3">
        <label for="month" class="form-label">Select Month:</label>
        <select name="month" id="month" class="form-select" required>
            <?php
            for($m=1; $m<=12; $m++){
                $selected = ($m == $month) ? "selected" : "";
                $monthName = date("F", mktime(0,0,0,$m,1));
                echo "<option value='$m' $selected>$monthName</option>";
            }
            ?>
        </select>
    </div>
    <div class="col-md-3">
        <label for="year" class="form-label">Select Year:</label>
        <select name="year" id="year" class="form-select" required>
            <?php
            $currentYear = date("Y");
            for($y=$currentYear-5; $y<=$currentYear; $y++){
                $selected = ($y == $year) ? "selected" : "";
                echo "<option value='$y' $selected>$y</option>";
            }
            ?>
        </select>
    </div>
    <div class="col-md-3 align-self-end">
        <button type="submit" class="btn btn-primary w-100">Generate Summary</button>
    </div>
</form>

<!-- Summary Table -->
<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Total Present</th>
            <th>Total Late (minutes)</th>
            <th>Total Overtime (minutes)</th>
            <th>Total Absent</th>
            <th>Total Leave</th>
        </tr>
    </thead>
    <tbody>
        <?php if($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['emp_name']) ?></td>
                    <td><?= $row['total_attendance'] ?></td>
                    <td><?= $row['total_late'] ?></td>
                    <td><?= $row['total_overtime'] ?></td>
                    <td><?= $row['total_absent'] ?></td>
                    <td><?= $row['total_leave'] ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" class="text-center">No data found for selected month/year.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

</body>
</html>

<?php
class Department extends Model implements JsonSerializable{
	public $id;
	public $name;
	public $description;
	public $status;

	public function __construct(){
	}
	public function set($id,$name,$description,$status){
		$this->id=$id;
		$this->name=$name;
		$this->description=$description;
		$this->status=$status;

	}
	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}department(name,description,status)values('$this->name','$this->description','$this->status')");
		return $db->insert_id;
	}
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}department set name='$this->name',description='$this->description',status='$this->status' where id='$this->id'");
	}
	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}department where id={$id}");
	}
	public function jsonSerialize():mixed{
		return get_object_vars($this);
	}
	
	public static function getall(){
		global $db,$tx;
		$result=$db->query("select id,name,description,status from {$tx}department");
		$data=[];
		while($department=$result->fetch_object()){
			$data[]=$department;
		}

		return $data;

	}
	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select id,name,description,status from {$tx}department $criteria limit $top,$perpage");
		$data=[];
		while($department=$result->fetch_object()){
			$data[]=$department;
		}
			return $data;
	}
	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}department $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}
	public static function find($id){
		global $db,$tx;
		$result =$db->query("select id,name,description,status from {$tx}department where id='$id'");
		$department=$result->fetch_object();
			return $department;
	}
	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}department");
		$department =$result->fetch_object();
		return $department->last_id;
	}
	public function json(){
		return json_encode($this);
	}
	public function __toString(){
		return "		Id:$this->id<br> 
		Name:$this->name<br> 
		Description:$this->description<br> 
		Status:$this->status<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbDepartment"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}department");
		while($department=$result->fetch_object()){
			$html.="<option value ='$department->id'>$department->name</option>";
		}
		$html.="</select>";
		return $html;
	}


	static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true){
    global $db, $tx, $base_url;

    // Count total rows
    $count_result = $db->query("SELECT COUNT(*) total FROM {$tx}department $criteria");
    list($total_rows) = $count_result->fetch_row();
    $total_pages = ceil($total_rows / $perpage);
    $top = ($page - 1) * $perpage;

    // Fetch department data
    $result = $db->query("SELECT id, name, description, status FROM {$tx}department $criteria LIMIT $top, $perpage");

    // === Professional CSS Styling with borders ===
    $html = "<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');
    .dept-card {
        max-width: 1100px;
        margin: 25px auto;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.08);
        font-family: 'Poppins', sans-serif;
        overflow: hidden;
        border: 1px solid #e2e8f0;
    }
    .dept-card-header {
        background: linear-gradient(135deg,#2563eb,#1d4ed8);
        color: #fff;
        padding: 18px 25px;
        font-size: 20px;
        font-weight: 600;
        text-align: center;
    }
    .dept-card-body {
        padding: 20px 25px;
        overflow-x: auto;
    }
    .dept-table {
        width: 100%;
        border-collapse: collapse;
    }
    .dept-table th, .dept-table td {
        padding: 10px 12px;
        text-align: center;
        font-size: 14px;
        border: 1px solid #e2e8f0;
        word-wrap: break-word;
    }
    .dept-table th {
        background-color: #1f3d79ff;
        font-weight: 600;
        color: #e7e8eba9;
    }
      .btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group button {
    padding: 6px 10px !important; /* একটু বড় padding */
    font-size: 14px !important;   /* icon বড় দেখানোর জন্য */
    border-radius: 4px;
    border: 2px solid #000;       /* গাঢ় black border */
    outline: none;
    cursor: pointer;
    color: #fff;
    font-weight: 700;              /* icon/text bold */
    display: flex;
    align-items: center;
    justify-content: center;
}

.btn-group i {
    font-weight: 900; /* icon আরও bold */
}


.btn-group button:focus {
    outline: none;
    border: 1px solid rgba(0,0,0,0.3);
    box-shadow: none;
}
    .btn-primary { background: #3b82f6; }
    .btn-danger { background: #ef4444; }
    .dept-table tr:hover { background: #f1f5f9; transition: 0.2s; }
    @media (max-width: 768px) {
        .dept-table th, .dept-table td { font-size: 12px; padding: 6px 8px; }
        .btn-group button { font-size: 10px; padding: 3px 5px; }
    }
    </style>";

    $html .= "<div class='dept-card'>";
    $html .= "<div class='dept-card-header'>Department Section</div>";
    $html .= "<div class='dept-card-body'>";

    // New Department Button
    $html .= "<div style='margin-bottom:10px; text-align:right;'>
                <a href='{$base_url}/department/create' class='btn btn-success' style='padding:6px 12px;'>+ Add Department</a>
              </div>";

    // Table Start
    $html .= "<table class='dept-table'>";
    $html .= "<tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Status</th>";
    if($action) $html .= "<th>Action</th>";
    $html .= "</tr>";

    // Table Rows
    while($department = $result->fetch_object()){
        $html .= "<tr>
                    <td>$department->id</td>
                    <td>$department->name</td>
                    <td>$department->description</td>
                    <td>$department->status</td>";

        if($action){
            $html .= "<td style='white-space: nowrap;'>
                        <div class='btn-group'>
                            <button class='btn-primary' onclick=\"location.href='{$base_url}/department/edit/$department->id'\"><i class='fas fa-edit'></i></button>
                            <button class='btn-danger' onclick=\"if(confirm('Are you sure?')) location.href='{$base_url}/department/confirm/$department->id'\"><i class='fas fa-trash-alt'></i></button>
                        </div>
                      </td>";
        }

        $html .= "</tr>";
    }

    $html .= "</table>";

    // Pagination
    $html .= "<div style='margin-top:10px; text-align:center;'>" . pagination($page, $total_pages) . "</div>";

    $html .= "</div></div>";

    return $html;
}







	static function html_row_details($id){
		global $db,$tx,$base_url;
		$result =$db->query("select id,name,description,status from {$tx}department where id={$id}");
		$department=$result->fetch_object();
		$html="<table class='table'>";
		$html.="<tr><th colspan=\"2\">Department Show</th></tr>";
		$html.="<tr><th>Id</th><td>$department->id</td></tr>";
		$html.="<tr><th>Name</th><td>$department->name</td></tr>";
		$html.="<tr><th>Description</th><td>$department->description</td></tr>";
		$html.="<tr><th>Status</th><td>$department->status</td></tr>";

		$html.="</table>";
		return $html;
	}
}
?>

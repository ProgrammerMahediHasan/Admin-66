<?php
class LeavePolicy extends Model implements JsonSerializable{
	public $id;
	public $leave_type;
	public $days_allowed;
	public $approval_required;
	public $notes;
	public $created_time;

	public function __construct(){
	}
	public function set($id,$leave_type,$days_allowed,$approval_required,$notes,$created_time){
		$this->id=$id;
		$this->leave_type=$leave_type;
		$this->days_allowed=$days_allowed;
		$this->approval_required=$approval_required;
		$this->notes=$notes;
		$this->created_time=$created_time;

	}
	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}leave_policy(leave_type,days_allowed,approval_required,notes,created_time)values('$this->leave_type','$this->days_allowed','$this->approval_required','$this->notes','$this->created_time')");
		return $db->insert_id;
	}
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}leave_policy set leave_type='$this->leave_type',days_allowed='$this->days_allowed',approval_required='$this->approval_required',notes='$this->notes',created_time='$this->created_time' where id='$this->id'");
	}
	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}leave_policy where id={$id}");
	}
	public function jsonSerialize(){
		return get_object_vars($this);
	}
	public static function all(){
		global $db,$tx;
		$result=$db->query("select id,leave_type,days_allowed,approval_required,notes,created_time from {$tx}leave_policy");
		$data=[];
		while($leavepolicy=$result->fetch_object()){
			$data[]=$leavepolicy;
		}
			return $data;
	}
	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select id,leave_type,days_allowed,approval_required,notes,created_time from {$tx}leave_policy $criteria limit $top,$perpage");
		$data=[];
		while($leavepolicy=$result->fetch_object()){
			$data[]=$leavepolicy;
		}
			return $data;
	}
	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}leave_policy $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}
	public static function find($id){
		global $db,$tx;
		$result =$db->query("select id,leave_type,days_allowed,approval_required,notes,created_time from {$tx}leave_policy where id='$id'");
		$leavepolicy=$result->fetch_object();
			return $leavepolicy;
	}
	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}leave_policy");
		$leavepolicy =$result->fetch_object();
		return $leavepolicy->last_id;
	}
	public function json(){
		return json_encode($this);
	}
	public function __toString(){
		return "		Id:$this->id<br> 
		Leave Type:$this->leave_type<br> 
		Days Allowed:$this->days_allowed<br> 
		Approval Required:$this->approval_required<br> 
		Notes:$this->notes<br> 
		Created Time:$this->created_time<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbLeavePolicy"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}leave_policy");
		while($leavepolicy=$result->fetch_object()){
			$html.="<option value ='$leavepolicy->id'>$leavepolicy->name</option>";
		}
		$html.="</select>";
		return $html;
	}
	static function html_table($page = 1,$perpage = 10,$criteria="",$action=true){
		global $db,$tx,$base_url;
		$count_result =$db->query("select count(*) total from {$tx}leave_policy $criteria ");
		list($total_rows)=$count_result->fetch_row();
		$total_pages = ceil($total_rows /$perpage);
		$top = ($page - 1)*$perpage;
		$result=$db->query("select id,leave_type,days_allowed,approval_required,notes,created_time from {$tx}leave_policy $criteria limit $top,$perpage");
		$html="<table class='table'>";
			$html.="<tr><th colspan='3'>".Html::link(["class"=>"btn btn-success","route"=>"leavepolicy/create","text"=>"New LeavePolicy"])."</th></tr>";
		if($action){
			$html.="<tr><th>Id</th><th>Leave Type</th><th>Days Allowed</th><th>Approval Required</th><th>Notes</th><th>Created Time</th><th>Action</th></tr>";
		}else{
			$html.="<tr><th>Id</th><th>Leave Type</th><th>Days Allowed</th><th>Approval Required</th><th>Notes</th><th>Created Time</th></tr>";
		}
		while($leavepolicy=$result->fetch_object()){
			$action_buttons = "";
			if($action){
				$action_buttons = "<td><div class='btn-group' style='display:flex;'>";
				$action_buttons.= Event::button(["name"=>"show", "value"=>"Show", "class"=>"btn btn-info", "route"=>"leavepolicy/show/$leavepolicy->id"]);
				$action_buttons.= Event::button(["name"=>"edit", "value"=>"Edit", "class"=>"btn btn-primary", "route"=>"leavepolicy/edit/$leavepolicy->id"]);
				$action_buttons.= Event::button(["name"=>"delete", "value"=>"Delete", "class"=>"btn btn-danger", "route"=>"leavepolicy/confirm/$leavepolicy->id"]);
				$action_buttons.= "</div></td>";
			}
			$html.="<tr><td>$leavepolicy->id</td><td>$leavepolicy->leave_type</td><td>$leavepolicy->days_allowed</td><td>$leavepolicy->approval_required</td><td>$leavepolicy->notes</td><td>$leavepolicy->created_time</td> $action_buttons</tr>";
		}
		$html.="</table>";
		$html.= pagination($page,$total_pages);
		return $html;
	}
	static function html_row_details($id){
		global $db,$tx,$base_url;
		$result =$db->query("select id,leave_type,days_allowed,approval_required,notes,created_time from {$tx}leave_policy where id={$id}");
		$leavepolicy=$result->fetch_object();
		$html="<table class='table'>";
		$html.="<tr><th colspan=\"2\">LeavePolicy Show</th></tr>";
		$html.="<tr><th>Id</th><td>$leavepolicy->id</td></tr>";
		$html.="<tr><th>Leave Type</th><td>$leavepolicy->leave_type</td></tr>";
		$html.="<tr><th>Days Allowed</th><td>$leavepolicy->days_allowed</td></tr>";
		$html.="<tr><th>Approval Required</th><td>$leavepolicy->approval_required</td></tr>";
		$html.="<tr><th>Notes</th><td>$leavepolicy->notes</td></tr>";
		$html.="<tr><th>Created Time</th><td>$leavepolicy->created_time</td></tr>";

		$html.="</table>";
		return $html;
	}
}
?>

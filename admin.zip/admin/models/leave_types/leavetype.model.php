<?php
class LeaveType extends Model implements JsonSerializable{
	public $id;
	public $name;
	public $leave_code;
	public $total_days;
	public $description;
	public $status;

	public function __construct(){
	}
	public function set($id,$name,$leave_code,$total_days,$description,$status){
		$this->id=$id;
		$this->name=$name;
		$this->leave_code=$leave_code;
		$this->total_days=$total_days;
		$this->description=$description;
		$this->status=$status;

	}

	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}leave_types(name,leave_code,total_days,description,status)values('$this->name','$this->leave_code','$this->total_days','$this->description','$this->status')");
		return $db->insert_id;
	}
	
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}leave_types set name='$this->name',leave_code='$this->leave_code',total_days='$this->total_days',description='$this->description',status='$this->status' where id='$this->id'");
	}

	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}leave_types where id={$id}");
	}

	public function jsonSerialize():mixed{
		return get_object_vars($this);
	}

	public static function all(){
		global $db,$tx;
		$result=$db->query("select id,leave_name,leave_code,total_days,description,status from {$tx}leave_types");
		$data=[];
		while($leavetype=$result->fetch_object()){
			$data[]=$leavetype;
		}
			return $data;
	}

	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select id,leave_name,leave_code,total_days,description,status from {$tx}leave_types $criteria limit $top,$perpage");
		$data=[];
		while($leavetype=$result->fetch_object()){
			$data[]=$leavetype;
		}
			return $data;
	}

	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}leave_types $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}

	public static function find($id){
		global $db,$tx;
		$result =$db->query("select id,name,leave_code,total_days,description,status from {$tx}leave_types where id='$id'");
		$leavetype=$result->fetch_object();
			return $leavetype;
	}

	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}leave_types");
		$leavetype =$result->fetch_object();
		return $leavetype->last_id;
	}

	public function json(){
		return json_encode($this);
	}

	public function __toString(){
		return "		Id:$this->id<br> 
		Leave Name:$this->name<br> 
		Leave Code:$this->leave_code<br> 
		Total Days:$this->total_days<br> 
		Description:$this->description<br> 
		Status:$this->status<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbLeaveType"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}leave_types");
		while($leavetype=$result->fetch_object()){
			$html.="<option value ='$leavetype->id'>$leavetype->name</option>";
		}
		$html.="</select>";
		return $html;
	}

static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true)
{
    global $db, $tx, $base_url;

    $count_result = $db->query("SELECT COUNT(*) total FROM {$tx}leave_types $criteria");
    list($total_rows) = $count_result->fetch_row();
    $total_pages = ceil($total_rows / $perpage);
    $top = ($page - 1) * $perpage;

    $result = $db->query("
        SELECT id, name, leave_code, total_days, description, status
        FROM {$tx}leave_types $criteria
        LIMIT $top, $perpage
    ");



	
    /* ===== CSS (Employee table style) ===== */
    $html = "<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

    .table-responsive { overflow-x:auto; }

    .table-responsive table{
        width:100%;
        border-collapse:collapse;
        table-layout:fixed;
        font-family:'Poppins',sans-serif;
    }

    .table-responsive th{
        background:#1f3d79ff; /* employee table header bg */
        color:#ffffff !important; /* white text */
        font-weight:700;          /* bold */
        text-align:center;
        padding:8px;
        font-size:13px;
    }

    .table-responsive td{
        text-align:center;
        vertical-align:middle;
        padding:6px 8px;
        font-size:12px;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }

    .table-responsive tr:hover{
        background:#f1f5f9;
        transition:0.2s;
    }

    .btn-group{
        display:flex !important;
        justify-content:center;
        gap:6px;
        flex-wrap:nowrap;
    }

    .btn-group button{
        padding:6px 10px !important;
        font-size:14px !important;
        border-radius:4px;
        border:2px solid #000;
        cursor:pointer;
        color:#fff;
        font-weight:700;
        display:flex;
        align-items:center;
        justify-content:center;
    }

    .btn-group i{
        font-weight:900;
    }

    .btn-primary{ background:#3b82f6; }
    .btn-danger{ background:#ef4444; }

    @media(max-width:768px){
        .table-responsive table th, .table-responsive table td{
            font-size:11px;
            padding:5px 6px;
        }
        .btn-group button{
            font-size:10px !important;
            width:26px;
            height:26px;
            padding:2px 5px !important;
        }
        .btn-group i{
            font-size:12px;
        }
    }
    </style>";
/* ===== Add Button Row ===== */
    $colspan = $action ? 7 : 6;
    $html .= "<tr>
        <th colspan='{$colspan}' class='text-center'>
            " . Html::link([
                "class" => "btn btn-success",
                "route" => "leavetype/create",
                "text"  => "+ Add Leave Type"
            ]) . "
        </th>
    </tr>";
    $html .= "<div class='table-responsive'>";
    $html .= "<table class='table table-bordered table-striped table-hover'>";

    

    /* ===== Table Head ===== */
    $html .= "<thead>
        <tr>
            
            <th>Leave Name</th>
            <th>Leave Code</th>
            <th>Total Leave Days</th>
            <th>Description</th>
            <th>Status</th>";
    if ($action) $html .= "<th>Action</th>";
    $html .= "</tr>
    </thead><tbody>";

    /* ===== Rows ===== */
    while ($lt = $result->fetch_object()) {
        $action_buttons = "";
        if ($action) {
            $action_buttons = "
            <td style='white-space:nowrap;'>
                <div class='btn-group'>
                    <button class='btn-primary' onclick=\"location.href='{$base_url}/leavetype/edit/$lt->id'\"><i class='fas fa-edit'></i></button>
                    <button class='btn-danger' onclick=\"if(confirm('Are you sure want to delete this Leave Type?')) location.href='{$base_url}/leavetype/confirm/$lt->id'\"><i class='fas fa-trash-alt'></i></button>
                </div>
            </td>";
        }

        $html .= "<tr>
           
            <td title='$lt->name'>$lt->name</td>
            <td>$lt->leave_code</td>
            <td>$lt->total_days</td>
            <td title='$lt->description'>$lt->description</td>
            <td>$lt->status</td>
            $action_buttons
        </tr>";
    }

    $html .= "</tbody></table></div>";

    /* ===== Pagination ===== */
    $html .= pagination($page, $total_pages);

    return $html;
}




static function html_row_details($id){
    global $db, $tx, $base_url;

    $result = $db->query("SELECT id, name, leave_code, total_days, description, status FROM {$tx}leave_types WHERE id={$id}");
    $leavetype = $result->fetch_object();

    $html = "<style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

        .details-table {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            border-collapse: collapse;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            background: #fff;
        }

        .details-table th, .details-table td {
            padding: 12px 15px;
            border: 1px solid #d1d5db;
            text-align: left;
            font-size: 14px;
            color: #000;
        }

        .details-table th {
            background: #1f3d79ff;
            color: #fff;
            font-weight: 600;
            width: 35%;
        }

        .details-table tr:nth-child(even) {
            background: #f2f2f2;
        }

        .details-table tr:hover {
            background: #f1f5f9;
            transition: 0.2s;
        }

        .details-table caption {
            caption-side: top;
            text-align: center;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #0d6efd;
        }
    </style>";

    $html .= "<table class='details-table'>";
    // $html .= "<caption>Leave Type Details</caption>";
    // $html .= "<tr><th>Id</th><td>$leavetype->id</td></tr>";
    $html .= "<tr><th>Leave Name</th><td>$leavetype->name</td></tr>";
    $html .= "<tr><th>Leave Code</th><td>$leavetype->leave_code</td></tr>";
    $html .= "<tr><th>Total Days</th><td>$leavetype->total_days</td></tr>";
    $html .= "<tr><th>Description</th><td>$leavetype->description</td></tr>";
    $html .= "<tr><th>Status</th><td>$leavetype->status</td></tr>";
    $html .= "</table>";

    return $html;
}



}
?>

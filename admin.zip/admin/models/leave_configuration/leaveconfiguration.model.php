<?php
class LeaveConfiguration extends Model implements JsonSerializable{
	public $id;
	public $leave_type;
	public $total_days;
	public $carry_forward;
	public $description;
	public $status;

	public function __construct(){
	}
	public function set($id,$leave_type,$total_days,$carry_forward,$description,$status){
		$this->id=$id;
		$this->leave_type=$leave_type;
		$this->total_days=$total_days;
		$this->carry_forward=$carry_forward;
		$this->description=$description;
		$this->status=$status;

	}
	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}leave_configuration(leave_type,total_days,carry_forward,description,status)values('$this->leave_type','$this->total_days','$this->carry_forward','$this->description','$this->status')");
		return $db->insert_id;
	}
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}leave_configuration set leave_type='$this->leave_type',total_days='$this->total_days',carry_forward='$this->carry_forward',description='$this->description',status='$this->status' where id='$this->id'");
	}
	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}leave_configuration where id={$id}");
	}
	public function jsonSerialize(){
		return get_object_vars($this);
	}
	public static function all(){
		global $db,$tx;
		$result=$db->query("select id,leave_type,total_days,carry_forward,description,status from {$tx}leave_configuration");
		$data=[];
		while($leaveconfiguration=$result->fetch_object()){
			$data[]=$leaveconfiguration;
		}
			return $data;
	}
	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select id,leave_type,total_days,carry_forward,description,status from {$tx}leave_configuration $criteria limit $top,$perpage");
		$data=[];
		while($leaveconfiguration=$result->fetch_object()){
			$data[]=$leaveconfiguration;
		}
			return $data;
	}
	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}leave_configuration $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}
	public static function find($id){
		global $db,$tx;
		$result =$db->query("select id,leave_type,total_days,carry_forward,description,status from {$tx}leave_configuration where id='$id'");
		$leaveconfiguration=$result->fetch_object();
			return $leaveconfiguration;
	}
	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}leave_configuration");
		$leaveconfiguration =$result->fetch_object();
		return $leaveconfiguration->last_id;
	}
	public function json(){
		return json_encode($this);
	}
	public function __toString(){
		return "		Id:$this->id<br> 
		Leave Type:$this->leave_type<br> 
		Total Days:$this->total_days<br> 
		Carry Forward:$this->carry_forward<br> 
		Description:$this->description<br> 
		Status:$this->status<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbLeaveConfiguration"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}leave_configuration");
		while($leaveconfiguration=$result->fetch_object()){
			$html.="<option value ='$leaveconfiguration->id'>$leaveconfiguration->name</option>";
		}
		$html.="</select>";
		return $html;
	}


	static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true) {
	global $db, $tx, $base_url;

	$count_result = $db->query("SELECT COUNT(*) total FROM {$tx}leave_configuration $criteria");
	list($total_rows) = $count_result->fetch_row();
	$total_pages = ceil($total_rows / $perpage);
	$top = ($page - 1) * $perpage;

	$result = $db->query("SELECT id, leave_type, total_days, carry_forward, description, status FROM {$tx}leave_configuration $criteria LIMIT $top, $perpage");

	// --- Table Layout ---
	$html  = "<div class='container mt-4'>";
	$html .= "<div class='card shadow-lg border-0 rounded-4'>";
	$html .= "<div class='card-header bg-primary text-white d-flex justify-content-between align-items-center rounded-top-4'>";
	$html .= "<h5 class='mb-0 fw-bold'>Leave Configuration List</h5>";
	$html .= Html::link(["class" => "btn btn-light fw-semibold", "route" => "leaveconfiguration/create", "text" => "+ Add Leave Policy"]);
	$html .= "</div>";
	$html .= "<div class='card-body p-4'>";

	$html .= "<table class='table table-bordered table-striped align-middle'>";
	$html .= "<thead class='table-dark'>";
	if ($action) {
		$html .= "<tr class='text-center'>
					<th style='width:60px;'>ID</th>
					<th>Leave Type</th>
					<th>Total Days</th>
					<th>Carry Forward</th>
					<th>Description</th>
					<th>Status</th>
					<th style='width:200px;'>Action</th>
				  </tr>";
	} else {
		$html .= "<tr class='text-center'>
					<th>ID</th>
					<th>Leave Type</th>
					<th>Total Days</th>
					<th>Carry Forward</th>
					<th>Description</th>
					<th>Status</th>
				  </tr>";
	}
	$html .= "</thead><tbody>";

	 $html .= "<style>
        .table thead th {
            background-color: #0d3b66; /* Deep blue */
            color: #d1d5db; /* Light ash */
            text-align: center;
            font-weight: 600;
        }
        .btn-group .btn {
            margin-right: 5px;
        }
				    .btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-primary { background: #3b82f6; }
    .btn-danger { background: #ef4444; }
    @media (max-width: 768px) {
        .table-responsive th, .table-responsive td {
            font-size: 12px;
            padding: 6px 8px;
        }
        .btn-group button {
            font-size: 10px;
            padding: 3px 6px;
        }

.btn-group button {
    padding: 6px 10px !important; 
    font-size: 14px !important;  
    border-radius: 4px;
    border: 2px solid #000;    
    outline: none;
    cursor: pointer;
    color: #fff;
    font-weight: 700;            
    display: flex;
    align-items: center;
    justify-content: center;
}

.btn-group i {
    font-weight: 900; /* icon আরও bold */
}


.btn-group button:focus {
    outline: none;
    border: 1px solid rgba(0,0,0,0.3);
    box-shadow: none;
}
    </style>";

	while ($leaveconfiguration = $result->fetch_object()) {
		$carry_forward = ($leaveconfiguration->carry_forward == 1) ? 
	"<span class='badge bg-success'>Yes</span>" : 
	"<span class='badge bg-danger'>No</span>";


		$status_badge = ($leaveconfiguration->status == 'Active') ? 
			"<span class='badge bg-success'>Active</span>" : 
			"<span class='badge bg-danger'>Inactive</span>";

		$action_buttons = "";
		if ($action) {
            $action_buttons = "<td style='white-space: nowrap;'>
                                <div class='btn-group'>
                                    <button class='btn-primary' onclick=\"location.href='{$base_url}/leaveconfiguration/edit/$leaveconfiguration->id'\"><i class='fas fa-edit'></i></button>
                                    <button class='btn-danger' onclick=\"if(confirm('Are you sure?')) location.href='{$base_url}/leaveconfiguration/confirm/$leaveconfiguration->id'\"><i class='fas fa-trash-alt'></i></button>
                                </div>
                              </td>";
        }

		$html .= "
			<tr>
				<td class='text-center fw-semibold'>{$leaveconfiguration->id}</td>
				<td>{$leaveconfiguration->leave_type}</td>
				<td class='text-center'>{$leaveconfiguration->total_days}</td>
				<td class='text-center'>$carry_forward</td>
				<td>{$leaveconfiguration->description}</td>
				<td class='text-center'>$status_badge</td>
				$action_buttons
			</tr>";
	}

	$html .= "</tbody></table>";
	$html .= pagination($page, $total_pages);
	$html .= "</div></div></div>";

	return $html;
}





	static function html_row_details($id){
		global $db,$tx,$base_url;
		$result =$db->query("select id,leave_type,total_days,carry_forward,description,status from {$tx}leave_configuration where id={$id}");
		$leaveconfiguration=$result->fetch_object();
		$html="<table class='table'>";
		$html.="<tr><th colspan=\"2\">LeaveConfiguration Show</th></tr>";
		$html.="<tr><th>Id</th><td>$leaveconfiguration->id</td></tr>";
		$html.="<tr><th>Leave Type</th><td>$leaveconfiguration->leave_type</td></tr>";
		$html.="<tr><th>Total Days</th><td>$leaveconfiguration->total_days</td></tr>";
		$html.="<tr><th>Carry Forward</th><td>$leaveconfiguration->carry_forward</td></tr>";
		$html.="<tr><th>Description</th><td>$leaveconfiguration->description</td></tr>";
		$html.="<tr><th>Status</th><td>$leaveconfiguration->status</td></tr>";

		$html.="</table>";
		return $html;
	}
}
?>

<?php
class LeaveAssign extends Model implements JsonSerializable{
	public $id;
	public $emp_id;
	public $leave_type_id;
	public $allow_days;
	public $used_days;
	public $year;
	// public $created_at;
	// public $updated_at;

	public function __construct(){
	}
	public function set($id,$emp_id,$leave_type_id,$allow_days,$used_days,$year,$created_at,$updated_at){
		$this->id=$id;
		$this->emp_id=$emp_id;
		$this->leave_type_id=$leave_type_id;
		$this->allow_days=$allow_days;
		$this->used_days=$used_days;
		$this->year=$year;
		// $this->created_at=$created_at;
		// $this->updated_at=$updated_at;

	}
	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}leave_assign(emp_id,leave_type_id,allow_days,used_days,year,created_at,updated_at)values('$this->emp_id','$this->leave_type_id','$this->allow_days','$this->used_days','$this->year','$this->created_at','$this->updated_at')");
		return $db->insert_id;
	}
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}leave_assign set emp_id='$this->emp_id',leave_type_id='$this->leave_type_id',allow_days='$this->allow_days',used_days='$this->used_days',year='$this->year',created_at='$this->created_at',updated_at='$this->updated_at' where id='$this->id'");
	}
	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}leave_assign where id={$id}");
	}
	public function jsonSerialize(){
		return get_object_vars($this);
	}
	public static function all(){
		global $db,$tx;
		$result=$db->query("select id,emp_id,leave_type_id,allow_days,used_days,year,created_at,updated_at from {$tx}leave_assign");
		$data=[];
		while($leaveassign=$result->fetch_object()){
			$data[]=$leaveassign;
		}
			return $data;
	}
	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select id,emp_id,leave_type_id,allow_days,used_days,year,created_at,updated_at from {$tx}leave_assign $criteria limit $top,$perpage");
		$data=[];
		while($leaveassign=$result->fetch_object()){
			$data[]=$leaveassign;
		}
			return $data;
	}
	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}leave_assign $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}
	public static function find($id){
		global $db,$tx;
		$result =$db->query("select id,emp_id,leave_type_id,allow_days,used_days,year,created_at,updated_at from {$tx}leave_assign where id='$id'");
		$leaveassign=$result->fetch_object();
			return $leaveassign;
	}
	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}leave_assign");
		$leaveassign =$result->fetch_object();
		return $leaveassign->last_id;
	}
	public function json(){
		return json_encode($this);
	}
	public function __toString(){
		return "		Id:$this->id<br> 
		Emp Id:$this->emp_id<br> 
		Leave Type Id:$this->leave_type_id<br> 
		Allow Days:$this->allow_days<br> 
		Used Days:$this->used_days<br> 
		Year:$this->year<br> 
		// Created At:$this->created_at<br> 
		// Updated At:$this->updated_at<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbLeaveAssign"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}leave_assign");
		while($leaveassign=$result->fetch_object()){
			$html.="<option value ='$leaveassign->id'>$leaveassign->name</option>";
		}
		$html.="</select>";
		return $html;
	}
	static function html_table($page = 1,$perpage = 10,$criteria="",$action=true){
		global $db,$tx,$base_url;
		$count_result =$db->query("select count(*) total from {$tx}leave_assign $criteria ");
		list($total_rows)=$count_result->fetch_row();
		$total_pages = ceil($total_rows /$perpage);
		$top = ($page - 1)*$perpage;
		$result=$db->query("select id,emp_id,leave_type_id,allow_days,used_days,year,created_at,updated_at from {$tx}leave_assign $criteria limit $top,$perpage");
		$html="<table class='table'>";
			$html.="<tr><th colspan='3'>".Html::link(["class"=>"btn btn-success","route"=>"leaveassign/create","text"=>"New LeaveAssign"])."</th></tr>";
		if($action){
			$html.="<tr><th>Id</th><th>Emp Id</th><th>Leave Type Id</th><th>Allow Days</th><th>Used Days</th><th>Year</th><th>Action</th></tr>";
		}else{
			$html.="<tr><th>Id</th><th>Emp Id</th><th>Leave Type Id</th><th>Allow Days</th><th>Used Days</th><th>Year</th></tr>";
		}
		while($leaveassign=$result->fetch_object()){
			$action_buttons = "";
			if($action){
				$action_buttons = "<td><div class='btn-group' style='display:flex;'>";
				$action_buttons.= Event::button(["name"=>"show", "value"=>"Show", "class"=>"btn btn-info", "route"=>"leaveassign/show/$leaveassign->id"]);
				$action_buttons.= Event::button(["name"=>"edit", "value"=>"Edit", "class"=>"btn btn-primary", "route"=>"leaveassign/edit/$leaveassign->id"]);
				$action_buttons.= Event::button(["name"=>"delete", "value"=>"Delete", "class"=>"btn btn-danger", "route"=>"leaveassign/confirm/$leaveassign->id"]);
				$action_buttons.= "</div></td>";
			}
			$html.="<tr><td>$leaveassign->id</td><td>$leaveassign->emp_id</td><td>$leaveassign->leave_type_id</td><td>$leaveassign->allow_days</td><td>$leaveassign->used_days</td><td>$leaveassign->year</td> $action_buttons</tr>";
		}
		$html.="</table>";
		$html.= pagination($page,$total_pages);
		return $html;
	}
	static function html_row_details($id){
		global $db,$tx,$base_url;
		$result =$db->query("select id,emp_id,leave_type_id,allow_days,used_days,year,created_at,updated_at from {$tx}leave_assign where id={$id}");
		$leaveassign=$result->fetch_object();
		$html="<table class='table'>";
		$html.="<tr><th colspan=\"2\">LeaveAssign Show</th></tr>";
		$html.="<tr><th>Id</th><td>$leaveassign->id</td></tr>";
		$html.="<tr><th>Emp Id</th><td>$leaveassign->emp_id</td></tr>";
		$html.="<tr><th>Leave Type Id</th><td>$leaveassign->leave_type_id</td></tr>";
		$html.="<tr><th>Allow Days</th><td>$leaveassign->allow_days</td></tr>";
		$html.="<tr><th>Used Days</th><td>$leaveassign->used_days</td></tr>";
		$html.="<tr><th>Year</th><td>$leaveassign->year</td></tr>";
		// $html.="<tr><th>Created At</th><td>$leaveassign->created_at</td></tr>";
		// $html.="<tr><th>Updated At</th><td>$leaveassign->updated_at</td></tr>";

		$html.="</table>";
		return $html;
	}
}
?>

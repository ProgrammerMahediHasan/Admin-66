<?php
class Designation extends Model implements JsonSerializable
{
	public $id;
	public $name;
	public $description;

	public function __construct() {}
	public function set($id, $name, $description)
	{
		$this->id = $id;
		$this->name = $name;
		$this->description = $description;
	}
	public function save()
	{
		global $db, $tx;
		$db->query("insert into {$tx}designations(name,description)values('$this->name','$this->description')");
		return $db->insert_id;
	}
	public function update()
	{
		global $db, $tx;
		$db->query("update {$tx}designations set name='$this->name',description='$this->description' where id='$this->id'");
	}
	public static function delete($id)
	{
		global $db, $tx;
		$db->query("delete from {$tx}designations where id={$id}");
	}
	public function jsonSerialize(): mixed
	{
		return get_object_vars($this);
	}


	public static function getall()
	{
		global $db, $tx;
		$result = $db->query("select id,name,description from {$tx}designations");
		$data = [];
		while ($designations = $result->fetch_object()) {
		
			$data[] = $designations;
		}

		return $data;
	}


	public static function pagination($page = 1, $perpage = 10, $criteria = "")
	{
		global $db, $tx;
		$top = ($page - 1) * $perpage;
		$result = $db->query("select id,name,description from {$tx}designations $criteria limit $top,$perpage");
		$data = [];
		while ($designation = $result->fetch_object()) {
			$data[] = $designation;
		}
		return $data;
	}
	public static function count($criteria = "")
	{
		global $db, $tx;
		$result = $db->query("select count(*) from {$tx}designations $criteria");
		list($count) = $result->fetch_row();
		return $count;
	}
	public static function find($id)
	{
		global $db, $tx;
		$result = $db->query("select id,name,description from {$tx}designations where id='$id'");
		$designation = $result->fetch_object();
		return $designation;
	}

	public static function getByDepartment($dept_id)
	{
		global $db, $tx;
		$result = $db->query("select id,name,description from {$tx}designations WHERE dept_id = $dept_id");
		$row = [];
		while ($designation = $result->fetch_object()) {
			$row[] = $designation;
		};
		return $row;
	}
	static function get_last_id()
	{
		global $db, $tx;
		$result = $db->query("select max(id) last_id from {$tx}designations");
		$designation = $result->fetch_object();
		return $designation->last_id;
	}
	public function json()
	{
		return json_encode($this);
	}
	public function __toString()
	{
		return "		Id:$this->id<br> 
		Name:$this->name<br> 
		Description:$this->description<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name = "cmbDesignation")
	{
		global $db, $tx;
		$html = "<select id='$name' name='$name'> ";
		$result = $db->query("select id,name from {$tx}designations");
		while ($designation = $result->fetch_object()) {
			$html .= "<option value ='$designation->id'>$designation->name</option>";
		}
		$html .= "</select>";
		return $html;
	}



	static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true)
{
    global $db, $tx, $base_url;

    // Count total rows
    $count_result = $db->query("SELECT COUNT(*) total FROM {$tx}designations $criteria");
    list($total_rows) = $count_result->fetch_row();
    $total_pages = ceil($total_rows / $perpage);
    $top = ($page - 1) * $perpage;

    // Fetch designation data
    $result = $db->query("SELECT id, name, description FROM {$tx}designations $criteria LIMIT $top, $perpage");

    // === Stylish Table CSS ===
    $html = "<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

    .table-responsive {
        overflow-x: auto;
        margin-top: 20px;
    }
    .table-responsive table {
        width: 100%;
        border-collapse: collapse;
        font-family: 'Poppins', sans-serif;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        table-layout: auto; /* auto layout for flexible columns */
    }
    .table-responsive th, .table-responsive td {
        border: 1px solid #d1d5db;
        padding: 10px 12px;
        font-size: 13px;
        text-align: center;
        word-wrap: break-word;
    }
    .table-responsive th {
        background: linear-gradient(135deg, #213f80ff, #1d4ed8);
        color: #f1eaeaec;
        font-weight: 700;
        text-transform: uppercase;
    }
    .table-responsive tr:hover {
        background-color: #f1f5f9;
        transition: 0.2s;
    }
    .table-responsive th.id, .table-responsive td.id {
        width: 50px; /* Minimal width for ID */
    }
    .table-responsive th.name, .table-responsive td.name {
        width: 150px; /* Minimal width for Name */
    }
    .table-responsive th.description, .table-responsive td.description {
        width: auto; /* Remaining space for Description */
    }
    .btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group {
    display: flex !important;
    justify-content: center;
    gap: 6px; /* হালকা gap */
    flex-wrap: nowrap;
}

.btn-group button {
    padding: 6px 10px !important; /* একটু বড় padding */
    font-size: 14px !important;   /* icon বড় দেখানোর জন্য */
    border-radius: 4px;
    border: 2px solid #000;       /* গাঢ় black border */
    outline: none;
    cursor: pointer;
    color: #fff;
    font-weight: 700;              /* icon/text bold */
    display: flex;
    align-items: center;
    justify-content: center;
}

.btn-group i {
    font-weight: 900; /* icon আরও bold */
}


.btn-group button:focus {
    outline: none;
    border: 1px solid rgba(0,0,0,0.3);
    box-shadow: none;
}
		.btn-primary { background: #3b82f6; }
    .btn-danger { background: #ef4444; }
    @media (max-width: 768px) {
        .table-responsive th, .table-responsive td {
            font-size: 12px;
            padding: 6px 8px;
        }
        .btn-group button {
            font-size: 10px;
            padding: 3px 6px;
        }

    }
    </style>";

    $html .= "<div class='table-responsive'>";
    $html .= "<table class='table table-bordered table-striped table-hover'>";
    
    // New Designation button
    $html .= "<tr><th colspan='" . ($action ? 4 : 3) . "' class='text-center'>"
           . Html::link(["class" => "btn btn-success", "route" => "designation/create", "text" => "+ Add Designation"])
           . "</th></tr>";

    // Table headers
    if ($action) {
        $html .= "<tr>
                    <th class='id'>ID</th>
                    <th class='name'>Name</th>
                    <th class='description'>Description</th>
                    <th>Action</th>
                  </tr>";
    } else {
        $html .= "<tr>
                    <th class='id'>ID</th>
                    <th class='name'>Name</th>
                    <th class='description'>Description</th>
                  </tr>";
    }

    // Table rows
    while ($designation = $result->fetch_object()) {
        $action_buttons = "";
        if ($action) {
            $action_buttons = "<td style='white-space: nowrap;'>
                                <div class='btn-group'>
                                    <button class='btn-primary' onclick=\"location.href='{$base_url}/designation/edit/$designation->id'\"><i class='fas fa-edit'></i></button>
                                    <button class='btn-danger' onclick=\"if(confirm('Are you sure?')) location.href='{$base_url}/designation/confirm/$designation->id'\"><i class='fas fa-trash-alt'></i></button>
                                </div>
                              </td>";
        }

        $html .= "<tr>
                    <td class='id'>$designation->id</td>
                    <td class='name'>$designation->name</td>
                    <td class='description'>$designation->description</td>
                    $action_buttons
                  </tr>";
    }

    $html .= "</table>";
    $html .= "</div>";

    // Pagination
    $html .= "<div style='margin-top:15px; text-align:center;'>" . pagination($page, $total_pages) . "</div>";

    return $html;
}







	static function html_row_details($id)
	{
		global $db, $tx, $base_url;
		$result = $db->query("select id,name,description from {$tx}designations where id={$id}");
		$designation = $result->fetch_object();
		$html = "<table class='table'>";
		$html .= "<tr><th colspan=\"2\">Designation Show</th></tr>";
		$html .= "<tr><th>Id</th><td>$designation->id</td></tr>";
		$html .= "<tr><th>Name</th><td>$designation->name</td></tr>";
		$html .= "<tr><th>Description</th><td>$designation->description</td></tr>";

		$html .= "</table>";
		return $html;
	}
}

<?php
class LeaveRequest extends Model implements JsonSerializable{
	public $leave_id;
	public $emp_id;
	public $leave_type;
	public $start_date;
	public $end_date;
	public $total_days;
	public $reason;
	public $status;
	public $approver_id;
	public $applied_on;

	public function __construct(){
	}
	public function set($leave_id,$emp_id,$leave_type,$start_date,$end_date,$total_days,$reason,$status,$approver_id,$applied_on){
		$this->leave_id=$leave_id;
		$this->emp_id=$emp_id;
		$this->leave_type=$leave_type;
		$this->start_date=$start_date;
		$this->end_date=$end_date;
		$this->total_days=$total_days;
		$this->reason=$reason;
		$this->status=$status;
		$this->approver_id=$approver_id;
		$this->applied_on=$applied_on;

	}
	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}leave_request(leave_id,emp_id,leave_type,start_date,end_date,total_days,reason,status,approver_id,applied_on)values('$this->leave_id','$this->emp_id','$this->leave_type','$this->start_date','$this->end_date','$this->total_days','$this->reason','$this->status','$this->approver_id','$this->applied_on')");
		return $db->insert_id;
	}
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}leave_request set leave_id='$this->leave_id',emp_id='$this->emp_id',leave_type='$this->leave_type',start_date='$this->start_date',end_date='$this->end_date',total_days='$this->total_days',reason='$this->reason',status='$this->status',approver_id='$this->approver_id',applied_on='$this->applied_on' where id='$this->id'");
	}
	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}leave_request where leave_id={$id}");
	}
	public function jsonSerialize():mixed{
		return get_object_vars($this);
	}
	public static function all(){
		global $db,$tx;
		$result=$db->query("select leave_id,emp_id,leave_type,start_date,end_date,total_days,reason,status,approver_id,applied_on from {$tx}leave_request");
		$data=[];
		while($leaverequest=$result->fetch_object()){
			$data[]=$leaverequest;
		}
			return $data;
	}
	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select leave_id,emp_id,leave_type,start_date,end_date,total_days,reason,status,approver_id,applied_on from {$tx}leave_request $criteria limit $top,$perpage");
		$data=[];
		while($leaverequest=$result->fetch_object()){
			$data[]=$leaverequest;
		}
			return $data;
	}
	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}leave_request $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}
	public static function find($id){
		global $db,$tx;
		$result =$db->query("select leave_id,emp_id,leave_type,start_date,end_date,total_days,reason,status,approver_id,applied_on from {$tx}leave_request where leave_id='$id'");
		$leaverequest=$result->fetch_object();
			return $leaverequest;
	}
	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}leave_request");
		$leaverequest =$result->fetch_object();
		return $leaverequest->last_id;
	}
	public function json(){
		return json_encode($this);
	}
	public function __toString(){
		return "		Leave Id:$this->leave_id<br> 
		Emp Id:$this->emp_id<br> 
		Leave Type:$this->leave_type<br> 
		Start Date:$this->start_date<br> 
		End Date:$this->end_date<br> 
		Total Days:$this->total_days<br> 
		Reason:$this->reason<br> 
		Status:$this->status<br> 
		Approver Id:$this->approver_id<br> 
		Applied On:$this->applied_on<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbLeaveRequest"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}leave_request");
		while($leaverequest=$result->fetch_object()){
			$html.="<option value ='$leaverequest->id'>$leaverequest->name</option>";
		}
		$html.="</select>";
		return $html;
	}


static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true)
{
    global $db, $tx, $base_url;

    // Total rows for pagination
    $count_result = $db->query("SELECT COUNT(*) total FROM {$tx}leave_request $criteria");
    list($total_rows) = $count_result->fetch_row();
    $total_pages = ceil($total_rows / $perpage);
    $top = ($page - 1) * $perpage;

    // Fetch leave requests
    $result = $db->query("SELECT leave_id, emp_id, leave_type, start_date, end_date, total_days, reason, status, approver_id, applied_on FROM {$tx}leave_request $criteria LIMIT $top, $perpage");

    // CSS for responsive table
    $html = "<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

    .table-responsive { overflow-x:auto; margin-top:20px; }
    .table-responsive table {
        width:100%;
        border-collapse:collapse;
        table-layout:fixed;
        font-family:'Poppins',sans-serif;
        box-shadow:0 4px 15px rgba(0,0,0,.08);
    }
    .table-responsive th {
        background:#1f3d79;
        color:#fff;
        font-size:13px;
        padding:8px;
        text-align:center;
    }
    .table-responsive td {
        font-size:12px;
        padding:6px 8px;
        text-align:center;
        white-space:nowrap;
        overflow:hidden;
        text-overflow:ellipsis;
    }
    .table-responsive tr:hover { background:#f1f5f9; transition:0.2s; }
    .btn-group { display:flex !important; justify-content:center; gap:6px; }
    .btn-group button {
        border:2px solid #000;
        padding:6px 10px;
        font-weight:700;
        color:#fff;
        cursor:pointer;
        border-radius:4px;
    }
    .btn-primary { background:#3b82f6; }
    .btn-danger { background:#ef4444; }
    @media(max-width:768px){
        .table-responsive table th, .table-responsive table td { font-size:11px; padding:5px 6px; }
        .btn-group button { font-size:10px; padding:2px 5px; }
    }
    </style>";

    // Add New Leave Request Button
    $colspan = $action ? 11 : 10;
    $html .= "<tr>
        <th colspan='{$colspan}' class='text-center'>
            " . Html::link([
                "class" => "btn btn-success",
                "route" => "leaverequest/create",
                "text"  => "+ Add Leave Request"
            ]) . "
        </th>
    </tr>";

    $html .= "<div class='table-responsive'>";
    $html .= "<table class='table table-bordered table-striped table-hover'>";

    // Table Head
    $html .= "<thead>
        <tr>
            <th>Leave ID</th>
            <th>Emp ID</th>
            <th>Leave Type</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Total Days</th>
            <th>Reason</th>
            <th>Status</th>
            <th>Approver ID</th>
            <th>Applied On</th>";
    if ($action) $html .= "<th>Action</th>";
    $html .= "</tr></thead><tbody>";

    // Table Rows
    while ($lr = $result->fetch_object()) {
        $action_buttons = "";
        if ($action) {
            $action_buttons = "
            <td>
                <div class='btn-group'>
                    <button class='btn-primary' onclick=\"location.href='{$base_url}/leaverequest/edit/$lr->leave_id'\"><i class='fas fa-edit'></i></button>
                    <button class='btn-danger' onclick=\"if(confirm('Are you sure want to delete this Leave Request?')) location.href='{$base_url}/leaverequest/confirm/$lr->leave_id'\"><i class='fas fa-trash-alt'></i></button>
                </div>
            </td>";
        }

        $html .= "<tr>
            <td>$lr->leave_id</td>
            <td>$lr->emp_id</td>
            <td>$lr->leave_type</td>
            <td>$lr->start_date</td>
            <td>$lr->end_date</td>
            <td>$lr->total_days</td>
            <td>$lr->reason</td>
            <td>$lr->status</td>
            <td>$lr->approver_id</td>
            <td>$lr->applied_on</td>
            $action_buttons
        </tr>";
    }

    $html .= "</tbody></table></div>";

    // Pagination
    $html .= pagination($page, $total_pages);

    return $html;
}



	
	static function html_row_details($id){
		global $db,$tx,$base_url;
		$result =$db->query("select leave_id,emp_id,leave_type,start_date,end_date,total_days,reason,status,approver_id,applied_on from {$tx}leave_request where leave_id={$id}");
		$leaverequest=$result->fetch_object();
		$html="<table class='table'>";
		$html.="<tr><th colspan=\"2\">LeaveRequest Show</th></tr>";
		$html.="<tr><th>Leave Id</th><td>$leaverequest->leave_id</td></tr>";
		$html.="<tr><th>Emp Id</th><td>$leaverequest->emp_id</td></tr>";
		$html.="<tr><th>Leave Type</th><td>$leaverequest->leave_type</td></tr>";
		$html.="<tr><th>Start Date</th><td>$leaverequest->start_date</td></tr>";
		$html.="<tr><th>End Date</th><td>$leaverequest->end_date</td></tr>";
		$html.="<tr><th>Total Days</th><td>$leaverequest->total_days</td></tr>";
		$html.="<tr><th>Reason</th><td>$leaverequest->reason</td></tr>";
		$html.="<tr><th>Status</th><td>$leaverequest->status</td></tr>";
		$html.="<tr><th>Approver Id</th><td>$leaverequest->approver_id</td></tr>";
		$html.="<tr><th>Applied On</th><td>$leaverequest->applied_on</td></tr>";

		$html.="</table>";
		return $html;
	}
}
?>

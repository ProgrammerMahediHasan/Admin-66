<?php
class LeaveRequest extends Model implements JsonSerializable{
	public $id;
	public $emp_id;
	public $leave_type;
	public $from_date;
	public $to_date;
	public $total_days;
	public $reason;
	public $attachment;
	public $status;
	public $applied_time;
	public $approved_by;
	public $approved_time;
	public $paid_leave;

	public function __construct(){
	}
	public function set($id,$emp_id,$leave_type,$from_date,$to_date,$total_days,$reason,$attachment,$status,$applied_time,$approved_by,$approved_time,$paid_leave){
		$this->id=$id;
		$this->emp_id=$emp_id;
		$this->leave_type=$leave_type;
		$this->from_date=$from_date;
		$this->to_date=$to_date;
		$this->total_days=$total_days;
		$this->reason=$reason;
		$this->attachment=$attachment;
		$this->status=$status;
		$this->applied_time=$applied_time;
		$this->approved_by=$approved_by;
		$this->approved_time=$approved_time;
		$this->paid_leave=$paid_leave;

	}
	public function save(){
		global $db,$tx;
		$db->query("insert into {$tx}leave_request(emp_id,leave_type,from_date,to_date,total_days,status,applied_time,approved_by,approved_time)values('$this->emp_id','$this->leave_type','$this->from_date','$this->to_date','$this->total_days','$this->status','$this->applied_time','$this->approved_by','$this->approved_time')");
		return $db->insert_id;
	}
	public function update(){
		global $db,$tx;
		$db->query("update {$tx}leave_request set emp_id='$this->emp_id',leave_type='$this->leave_type',from_date='$this->from_date',to_date='$this->to_date',total_days='$this->total_days',status='$this->status',applied_time='$this->applied_time',approved_by='$this->approved_by',approved_time='$this->approved_time' where id='$this->id'");
	}
	public static function delete($id){
		global $db,$tx;
		$db->query("delete from {$tx}leave_request where id={$id}");
	}
	public function jsonSerialize(){
		return get_object_vars($this);
	}
	public static function all(){
		global $db,$tx;
		$result=$db->query("select id,emp_id,leave_type,from_date,to_date,total_days,status,applied_time,approved_by,approved_time from {$tx}leave_request");
		$data=[];
		while($leaverequest=$result->fetch_object()){
			$data[]=$leaverequest;
		}
			return $data;
	}
	public static function pagination($page=1,$perpage=10,$criteria=""){
		global $db,$tx;
		$top=($page-1)*$perpage;
		$result=$db->query("select id,emp_id,leave_type,from_date,to_date,total_days,status,applied_time,approved_by,approved_time from {$tx}leave_request $criteria limit $top,$perpage");
		$data=[];
		while($leaverequest=$result->fetch_object()){
			$data[]=$leaverequest;
		}
			return $data;
	}
	public static function count($criteria=""){
		global $db,$tx;
		$result =$db->query("select count(*) from {$tx}leave_request $criteria");
		list($count)=$result->fetch_row();
			return $count;
	}
	public static function find($id){
		global $db,$tx;
		$result =$db->query("select id,emp_id,leave_type,from_date,to_date,total_days,status,applied_time,approved_by,approved_time from {$tx}leave_request where id='$id'");
		$leaverequest=$result->fetch_object();
			return $leaverequest;
	}
	static function get_last_id(){
		global $db,$tx;
		$result =$db->query("select max(id) last_id from {$tx}leave_request");
		$leaverequest =$result->fetch_object();
		return $leaverequest->last_id;
	}
	public function json(){
		return json_encode($this);
	}
	public function __toString(){
		return "		Id:$this->id<br> 
		Emp Id:$this->emp_id<br> 
		Leave Type:$this->leave_type<br> 
		From Date:$this->from_date<br> 
		To Date:$this->to_date<br> 
		Total Days:$this->total_days<br> 
		// Reason:$this->reason<br> 
		// Attachment:$this->attachment<br> 
		Status:$this->status<br> 
		Applied Time:$this->applied_time<br> 
		Approved By:$this->approved_by<br> 
		Approved Time:$this->approved_time<br> 
		// Paid Leave:$this->paid_leave<br> 
";
	}

	//-------------HTML----------//

	static function html_select($name="cmbLeaveRequest"){
		global $db,$tx;
		$html="<select id='$name' name='$name'> ";
		$result =$db->query("select id,name from {$tx}leave_request");
		while($leaverequest=$result->fetch_object()){
			$html.="<option value ='$leaverequest->id'>$leaverequest->name</option>";
		}
		$html.="</select>";
		return $html;
	}


	static function html_table($page = 1, $perpage = 10, $criteria = "", $action = true) {
    global $db, $tx, $base_url;

    // --- Pagination Calculation ---
    $count_result = $db->query("SELECT COUNT(*) total FROM {$tx}leave_request $criteria");
    list($total_rows) = $count_result->fetch_row();
    $total_pages = ceil($total_rows / $perpage);
    $top = ($page - 1) * $perpage;

    // --- Fetch Leave Requests with Employee Name ---
    $result = $db->query("
        SELECT 
    lr.id, 
    e.name as employee_name, 
    lr.leave_type, 
    lr.from_date, 
    lr.to_date, 
    lr.total_days, 
    lr.status, 
    lr.applied_time, 
    lr.approved_by
FROM leave_request lr
LEFT JOIN employees e ON lr.emp_id = e.id
$criteria
LIMIT $top, $perpage
    ");

    // --- Table Layout ---
    $html  = "<div class='container mt-4'>";
    $html .= "<div class='card shadow-lg border-0 rounded-4'>";
    $html .= "<div class='card-header bg-primary text-white d-flex justify-content-between align-items-center rounded-top-4'>";
    $html .= "<h5 class='mb-0 fw-bold'>Leave Request List</h5>";
    $html .= Html::link(["class"=>"btn btn-light fw-semibold","route"=>"leaverequest/create","text"=>"+ New Leave Request"]);
    $html .= "</div>";
    $html .= "<div class='card-body p-4 table-responsive'>";
    $html .= "<table class='table table-bordered table-striped align-middle'>";
    $html .= "<thead class='table-dark text-center'>";
    $html .= "<tr>
                <th>Employee</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Total Days</th>
                <th>Leave Status</th>
                <th>Applied Time</th>
                <th>Approved By</th>";

    if($action) $html .= "<th>Action</th>";
    $html .= "</tr></thead><tbody>";

    // --- Styles ---
    $html .= "<style>
        .table thead th {
            background-color: #0d3b66; /* Deep blue */
            color: #d1d5db; /* Light ash */
            text-align: center;
            font-weight: 600;
        }
        .btn-group .btn {
            margin-right: 5px;
        }
        .btn-group {
            display: flex !important;
            justify-content: center;
            gap: 6px;
            flex-wrap: nowrap;
        }
        .btn-primary { background: #3b82f6; }
        .btn-danger { background: #ef4444; }
        @media (max-width: 768px) {
            .table-responsive th, .table-responsive td { font-size: 12px; padding: 6px 8px; }
            .btn-group button { font-size: 10px; padding: 3px 6px; }
        }
    </style>";

    // --- Row Loop ---
    while($leaverequest = $result->fetch_object()) {

        // --- Status Badge ---
        if($leaverequest->status == 'Approved'){
            $status_badge = "<span class='badge' style='background-color: #28a745; color: #fff;'>Approved</span>";
        } elseif($leaverequest->status == 'Rejected'){
            $status_badge = "<span class='badge' style='background-color: #dc3545; color: #fff;'>Rejected</span>";
        } else {
            $status_badge = "<span class='badge' style='background-color: #ffc107; color: #000;'>Pending</span>";
        }



     
        // --- Action Buttons ---
        $action_buttons = "";
        if($action){
            $action_buttons = "<td style='white-space: nowrap;'>
                                <div class='btn-group'>
                                    <button class='btn-primary' onclick=\"location.href='{$base_url}/leaverequest/edit/$leaverequest->id'\"><i class='fas fa-edit'></i></button>
                                    <button class='btn-danger' onclick=\"if(confirm('Are you sure?')) location.href='{$base_url}/leaverequest/confirm/$leaverequest->id'\"><i class='fas fa-trash-alt'></i></button>
                                </div>
                              </td>";
        }

        // --- Table Row ---
        $html .= "<tr class='text-center'>
                    <td>{$leaverequest->employee_name}</td>
                    <td>{$leaverequest->leave_type}</td>
                    <td>{$leaverequest->from_date}</td>
                    <td>{$leaverequest->to_date}</td>
                    <td>{$leaverequest->total_days}</td>
                    <td>{$status_badge}</td>
                    <td>{$leaverequest->applied_time}</td>
                    <td>{$leaverequest->approved_by}</td>
                    {$action_buttons}
                  </tr>";
    }

    $html .= "</tbody></table>";
    $html .= pagination($page, $total_pages);
    $html .= "</div></div></div>";

    return $html;
}







	static function html_row_details($id){
		global $db,$tx,$base_url;
		$result =$db->query("select id,emp_id,leave_type,from_date,to_date,total_days,reason,attachment,status,applied_time,approved_by,approved_time,paid_leave from {$tx}leave_request where id={$id}");
		$leaverequest=$result->fetch_object();
		$html="<table class='table'>";
		$html.="<tr><th colspan=\"2\">LeaveRequest Show</th></tr>";
		$html.="<tr><th>Id</th><td>$leaverequest->id</td></tr>";
		$html.="<tr><th>Emp Id</th><td>$leaverequest->emp_id</td></tr>";
		$html.="<tr><th>Leave Type</th><td>$leaverequest->leave_type</td></tr>";
		$html.="<tr><th>From Date</th><td>$leaverequest->from_date</td></tr>";
		$html.="<tr><th>To Date</th><td>$leaverequest->to_date</td></tr>";
		$html.="<tr><th>Total Days</th><td>$leaverequest->total_days</td></tr>";
		// $html.="<tr><th>Reason</th><td>$leaverequest->reason</td></tr>";
		// $html.="<tr><th>Attachment</th><td>$leaverequest->attachment</td></tr>";
		$html.="<tr><th>Status</th><td>$leaverequest->status</td></tr>";
		$html.="<tr><th>Applied Time</th><td>$leaverequest->applied_time</td></tr>";
		$html.="<tr><th>Approved By</th><td>$leaverequest->approved_by</td></tr>";
		$html.="<tr><th>Approved Time</th><td>$leaverequest->approved_time</td></tr>";
		// $html.="<tr><th>Paid Leave</th><td>$leaverequest->paid_leave</td></tr>";

		$html.="</table>";
		return $html;
	}
}
?>
